export type UserRole = 
  | 'admin' 
  | 'doctor' 
  | 'nurse' 
  | 'receptionist' 
  | 'pharmacist' 
  | 'lab_scientist'
  | 'patient';

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: UserRole;
  department: string;
  phone: string;
  avatarUrl?: string;
  active: boolean;
  licenseNumber?: string;
  createdAt: string;
  lastLogin?: string;
}

export interface VitalSigns {
  temperature: number; // in Celsius (e.g., 37.2)
  bloodPressureSys: number; // e.g., 120
  bloodPressureDia: number; // e.g., 80
  pulseRate: number; // bpm e.g., 78
  respiratoryRate: number; // cpm e.g., 18
  weight: number; // kg e.g., 72.5
  height?: number; // cm e.g., 175
  oxygenSaturation?: number; // % e.g., 98
  recordedAt: string;
  recordedBy: string;
}

export interface PrescriptionItem {
  id: string;
  drugName: string;
  dosage: string; // e.g. "500mg"
  frequency: string; // e.g. "TDS (3 times daily)"
  duration: string; // e.g. "5 days"
  route: string; // e.g. "Oral", "Intravenous", "Topical"
  instructions: string; // e.g. "Take after meals"
  status: 'pending' | 'dispensed' | 'cancelled';
  dispensedAt?: string;
  dispensedBy?: string;
}

export interface LabTest {
  id: string;
  patientId: string;
  doctorName: string;
  testName: string;
  category: 'Hematology' | 'Parasitology' | 'Microbiology' | 'Chemical Pathology' | 'Radiology';
  priority: 'Routine' | 'Urgent' | 'Stat';
  status: 'requested' | 'in_progress' | 'completed';
  requestDate: string;
  completedDate?: string;
  results?: string;
  scientistNotes?: string;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorName: string;
  doctorId: string;
  date: string;
  visitType: 'Outpatient' | 'Inpatient' | 'Emergency' | 'Follow-up' | 'Antenatal';
  chiefComplaint: string;
  historyOfPresentingIllness: string;
  vitals: VitalSigns;
  examinationFindings: string;
  diagnosis: string;
  icdCode?: string;
  treatmentPlan: string;
  prescriptions: PrescriptionItem[];
  labRequests?: string[];
  followUpDate?: string;
  status: 'completed' | 'draft';
}

export interface Patient {
  id: string; // e.g. "CMC-2026-0842"
  fullName: string;
  dateOfBirth: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  phone: string;
  email?: string;
  address: string;
  city: string; // e.g., Owerri
  lga: string; // e.g., Owerri Municipal, Owerri North, Owerri West
  state: string; // Imo State
  occupation: string;
  maritalStatus: 'Single' | 'Married' | 'Widowed' | 'Divorced';
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  genotype: 'AA' | 'AS' | 'SS' | 'AC';
  allergies: string[];
  chronicConditions: string[];
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  hmoProvider: string; // e.g. "Private / Self-Pay", "Hygeia HMO", "Imo Health Insurance (ImoCare)", "AXA Mansard"
  hmoNumber?: string;
  registeredAt: string;
  registeredBy: string;
  vitalsHistory: VitalSigns[];
  notes?: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  doctorName: string;
  doctorId: string;
  department: 'General Outpatient' | 'Internal Medicine' | 'Obstetrics & Gynaecology' | 'Paediatrics' | 'Surgery' | 'Cardiology' | 'Orthopaedics';
  date: string;
  time: string;
  reason: string;
  status: 'scheduled' | 'waiting' | 'in_consultation' | 'completed' | 'cancelled' | 'no_show';
  createdAt: string;
  notes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  module: string;
  details: string;
  ipAddress: string;
}

export interface HospitalStats {
  totalPatients: number;
  activeAppointmentsToday: number;
  consultationsToday: number;
  pendingPrescriptions: number;
  monthlyRegistrations: { month: string; count: number }[];
  topDiagnoses: { diagnosis: string; count: number; percentage: number }[];
  genderDistribution: { gender: string; count: number }[];
  departmentLoad: { department: string; count: number }[];
}
