import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { HospitalProvider, useHospital } from './context/HospitalContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { PatientDirectory } from './components/patients/PatientDirectory';
import { PatientRegistrationModal } from './components/patients/PatientRegistrationModal';
import { PatientDetailView } from './components/patients/PatientDetailView';
import { AppointmentManager } from './components/appointments/AppointmentManager';
import { ConsultationWorkspace } from './components/consultation/ConsultationWorkspace';
import { PharmacyDispensing } from './components/pharmacy/PharmacyDispensing';
import { LaboratoryWorkstation } from './components/laboratory/LaboratoryWorkstation';
import { UserManagement } from './components/users/UserManagement';
import { HospitalReports } from './components/reports/HospitalReports';
import { SystemArchitectureView } from './components/architecture/SystemArchitectureView';
import { Patient } from './types';

function MainAppContent() {
  const { currentUser } = useAuth();
  const { patients } = useHospital();

  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState<boolean>(false);
  const [appointmentPatient, setAppointmentPatient] = useState<Patient | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Unified Navigation Handler
  const handleNavigate = (view: string) => {
    if (view === 'registration') {
      setIsRegisterModalOpen(true);
    } else if (view === 'records' || view === 'patients') {
      setCurrentView('records');
    } else {
      setCurrentView(view);
    }
  };

  // Navigation Handlers
  const handleSelectPatient = (patientId: string) => {
    setSelectedPatientId(patientId);
    setCurrentView('patient-detail');
  };

  const handleStartConsultationForPatient = (patient: Patient) => {
    setSelectedPatientId(patient.id);
    setCurrentView('consultation');
  };

  const handleBookAppointmentForPatient = (patient: Patient) => {
    setAppointmentPatient(patient);
    setCurrentView('appointments');
  };

  const handlePatientRegisteredSuccess = (newPatient: Patient) => {
    setSelectedPatientId(newPatient.id);
    setCurrentView('patient-detail');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col antialiased text-slate-900">
      
      {/* Top Global Navigation Bar */}
      <Navbar
        onOpenRegistration={() => setIsRegisterModalOpen(true)}
        onSelectPatient={handleSelectPatient}
        onNavigate={handleNavigate}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* Main Body with Sidebar and Active View Content */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto p-4 sm:p-6 gap-6">
        
        {/* Left Navigation Sidebar */}
        <Sidebar
          currentView={currentView}
          onNavigate={handleNavigate}
          onSelectView={handleNavigate}
          isOpenMobile={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
        />

        {/* Dynamic Main Content Container */}
        <main className="flex-1 min-w-0">
          
          {/* 1. Overview Dashboard */}
          {currentView === 'dashboard' && (
            <OverviewDashboard
              onNavigate={handleNavigate}
              onSelectPatient={handleSelectPatient}
              onOpenNewRegistration={() => setIsRegisterModalOpen(true)}
              onOpenNewAppointment={() => {
                setAppointmentPatient(null);
                setCurrentView('appointments');
              }}
            />
          )}

          {/* 2. Patient Directory / EMR Records */}
          {(currentView === 'patients' || currentView === 'records') && (
            <PatientDirectory
              onSelectPatient={handleSelectPatient}
              onOpenNewRegistration={() => setIsRegisterModalOpen(true)}
              onOpenBookAppointment={handleBookAppointmentForPatient}
            />
          )}

          {/* 3. Patient Electronic Medical Record (EMR) Detail View */}
          {currentView === 'patient-detail' && selectedPatientId && (
            <PatientDetailView
              patientId={selectedPatientId}
              onBack={() => setCurrentView('records')}
              onStartConsultation={handleStartConsultationForPatient}
              onBookAppointment={handleBookAppointmentForPatient}
            />
          )}

          {/* 4. Appointments & Clinic Queue */}
          {currentView === 'appointments' && (
            <AppointmentManager
              onSelectPatient={handleSelectPatient}
              onOpenConsultationWithPatient={(patId) => {
                setSelectedPatientId(patId);
                setCurrentView('consultation');
              }}
              preSelectedPatient={appointmentPatient}
              onClearPreSelectedPatient={() => setAppointmentPatient(null)}
            />
          )}

          {/* 5. Doctor Consultation & Medical Records */}
          {currentView === 'consultation' && (
            <ConsultationWorkspace
              initialPatientId={selectedPatientId || undefined}
              onSelectPatientEMR={handleSelectPatient}
            />
          )}

          {/* 6. Pharmacy Dispensing */}
          {currentView === 'pharmacy' && (
            <PharmacyDispensing />
          )}

          {/* 7. Diagnostic Laboratory */}
          {currentView === 'laboratory' && (
            <LaboratoryWorkstation />
          )}

          {/* 8. User Management & Access Control */}
          {currentView === 'users' && (
            <UserManagement />
          )}

          {/* 9. Reports & Clinical Analytics */}
          {currentView === 'reports' && (
            <HospitalReports />
          )}

          {/* 10. Research Documentation & System Architecture (Chapter 3) & Security Audit */}
          {(currentView === 'architecture' || currentView === 'security') && (
            <SystemArchitectureView />
          )}

        </main>
      </div>

      {/* Patient Registration Modal */}
      <PatientRegistrationModal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
        onSuccess={handlePatientRegisteredSuccess}
      />

      {/* Footer Banner */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            <strong>Chidicon Cloud Health Information System</strong> • Designed & Implemented for Private Hospitals in Owerri, Imo State, Nigeria.
          </span>
          <span className="font-mono text-[11px] text-teal-800 font-semibold bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
            Node: Owerri-Cluster-01 (Encrypted Cloud Sync)
          </span>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <HospitalProvider>
        <MainAppContent />
      </HospitalProvider>
    </AuthProvider>
  );
}
