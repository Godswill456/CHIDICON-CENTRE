import React, { useState } from 'react';
import { 
  Stethoscope, 
  User, 
  Heart, 
  Activity, 
  Pill, 
  Plus, 
  Trash2, 
  Save, 
  TestTube2, 
  AlertCircle, 
  CheckCircle2, 
  Calendar,
  Sparkles,
  Search,
  BookOpen
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Patient, PrescriptionItem, VitalSigns } from '../../types';

interface ConsultationWorkspaceProps {
  initialPatientId?: string;
  onSelectPatientEMR: (patientId: string) => void;
}

const COMMON_DIAGNOSES = [
  { name: 'Acute Uncomplicated Malaria (P. falciparum)', icd: 'B50.9' },
  { name: 'Typhoid Enteritis / Enteric Fever', icd: 'A01.0' },
  { name: 'Essential Primary Hypertension', icd: 'I10' },
  { name: 'Type 2 Diabetes Mellitus with Hyperglycemia', icd: 'E11.65' },
  { name: 'Upper Respiratory Tract Infection (URTI)', icd: 'J06.9' },
  { name: 'Acute Gastroenteritis with Mild Dehydration', icd: 'A09' },
  { name: 'Peptic Ulcer Disease / H. pylori Gastritis', icd: 'K27.9' },
  { name: 'Bronchial Asthma (Acute Exacerbation)', icd: 'J45.901' },
  { name: 'Urinary Tract Infection (UTI)', icd: 'N39.0' },
  { name: 'Pelvic Inflammatory Disease (PID)', icd: 'N73.9' },
];

const COMMON_DRUGS = [
  'Artemether / Lumefantrine (Coartem 80/480mg Forte)',
  'Paracetamol Tablets 500mg',
  'Amoxicillin / Clavulanate (Augmentin 625mg)',
  'Ciprofloxacin 500mg Tablets',
  'Amlodipine 5mg / 10mg Tablets',
  'Telmisartan 40mg / 80mg Tablets',
  'Metformin 500mg / 850mg Tablets',
  'Omeprazole 20mg Capsules',
  'Oral Rehydration Salts (ORS) Sachet',
  'Ibuprofen 400mg Tablets',
  'Salbutamol Inhaler 100mcg',
  'Ceftriaxone 1g Injection',
];

export const ConsultationWorkspace: React.FC<ConsultationWorkspaceProps> = ({
  initialPatientId,
  onSelectPatientEMR,
}) => {
  const { patients, medicalRecords, createMedicalRecord, requestLabTest } = useHospital();
  const { currentUser } = useAuth();

  const [selectedPatientId, setSelectedPatientId] = useState<string>(
    initialPatientId || (patients[0]?.id || '')
  );

  const selectedPatient = patients.find(p => p.id === selectedPatientId);

  // Form State
  const [visitType, setVisitType] = useState<'Outpatient' | 'Inpatient' | 'Emergency' | 'Follow-up' | 'Antenatal'>('Outpatient');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [historyIllness, setHistoryIllness] = useState('');
  const [examinationFindings, setExaminationFindings] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [icdCode, setIcdCode] = useState('');
  const [treatmentPlan, setTreatmentPlan] = useState('');
  const [followUpDate, setFollowUpDate] = useState('2026-09-15');

  // Vitals State during consult
  const latestPatientVitals = selectedPatient?.vitalsHistory[0];
  const [vitals, setVitals] = useState<VitalSigns>({
    temperature: latestPatientVitals?.temperature || 37.0,
    bloodPressureSys: latestPatientVitals?.bloodPressureSys || 120,
    bloodPressureDia: latestPatientVitals?.bloodPressureDia || 80,
    pulseRate: latestPatientVitals?.pulseRate || 76,
    respiratoryRate: latestPatientVitals?.respiratoryRate || 18,
    weight: latestPatientVitals?.weight || 70,
    oxygenSaturation: latestPatientVitals?.oxygenSaturation || 98,
    recordedAt: 'Today',
    recordedBy: currentUser.name,
  });

  // Prescriptions List State
  const [prescriptions, setPrescriptions] = useState<PrescriptionItem[]>([
    {
      id: 'rx-1',
      drugName: 'Artemether / Lumefantrine (Coartem 80/480mg Forte)',
      dosage: '1 Tablet',
      frequency: 'BD (Twice daily)',
      duration: '3 days',
      route: 'Oral',
      instructions: 'Take with milk or fatty meal',
      status: 'pending',
    }
  ]);

  // Lab Requests State
  const [orderedLabs, setOrderedLabs] = useState<string[]>([]);
  const [selectedLabCategory, setSelectedLabCategory] = useState<'Parasitology' | 'Hematology' | 'Chemical Pathology' | 'Microbiology'>('Parasitology');
  const [selectedLabTest, setSelectedLabTest] = useState('Malaria Parasite (MP) by Thick Film');

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Add prescription item
  const handleAddPrescription = () => {
    const newItem: PrescriptionItem = {
      id: `rx-${Date.now()}`,
      drugName: COMMON_DRUGS[0],
      dosage: '1 Tablet',
      frequency: 'TDS (3 times daily)',
      duration: '5 days',
      route: 'Oral',
      instructions: 'Take after meals',
      status: 'pending',
    };
    setPrescriptions([...prescriptions, newItem]);
  };

  const handleRemovePrescription = (id: string) => {
    setPrescriptions(prescriptions.filter(p => p.id !== id));
  };

  const handleUpdatePrescription = (id: string, field: keyof PrescriptionItem, value: any) => {
    setPrescriptions(prescriptions.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const handleAddLabTest = () => {
    if (!orderedLabs.includes(selectedLabTest)) {
      setOrderedLabs([...orderedLabs, selectedLabTest]);
      if (selectedPatient) {
        requestLabTest({
          patientId: selectedPatient.id,
          doctorName: currentUser.name,
          testName: selectedLabTest,
          category: selectedLabCategory,
          priority: 'Routine',
        });
      }
    }
  };

  const handleRemoveLab = (testName: string) => {
    setOrderedLabs(orderedLabs.filter(l => l !== testName));
  };

  const handleSelectPredefinedDiagnosis = (diag: { name: string; icd: string }) => {
    setDiagnosis(diag.name);
    setIcdCode(diag.icd);
  };

  const handleSaveConsultation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) return;

    createMedicalRecord({
      patientId: selectedPatient.id,
      doctorName: currentUser.name,
      doctorId: currentUser.id,
      visitType,
      chiefComplaint: chiefComplaint.trim() || 'General clinical consultation and medical review',
      historyOfPresentingIllness: historyIllness.trim() || 'Patient presented for clinical evaluation.',
      vitals: {
        ...vitals,
        recordedAt: new Date().toLocaleString('en-US', { timeZone: 'Africa/Lagos' }) + ' WAT',
      },
      examinationFindings: examinationFindings.trim() || 'Conscious, stable vitals, no acute distress.',
      diagnosis: diagnosis.trim() || 'Clinical Review',
      icdCode: icdCode.trim() || undefined,
      treatmentPlan: treatmentPlan.trim() || 'Medication administered as prescribed. Rest and hydration advised.',
      prescriptions,
      labRequests: orderedLabs,
      followUpDate,
    });

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      // Reset form
      setChiefComplaint('');
      setHistoryIllness('');
      setExaminationFindings('');
      setDiagnosis('');
      setTreatmentPlan('');
    }, 2500);
  };

  const previousPatientRecords = medicalRecords.filter(r => r.patientId === selectedPatientId);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Title & Patient Selector Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-xs font-bold font-mono">
              Module 4 (Sec 3.6.2)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">Doctor Clinical Desk</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Doctor Medical Records & Consultation Workspace
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Record clinical findings, make ICD-10 diagnoses, generate e-prescriptions, and order lab tests.
          </p>
        </div>

        {/* Patient Switcher Dropdown */}
        <div className="flex items-center gap-2.5">
          <label className="text-xs font-bold text-slate-600 shrink-0">Consulting Patient:</label>
          <select
            value={selectedPatientId}
            onChange={e => setSelectedPatientId(e.target.value)}
            className="px-3.5 py-2 bg-slate-50 text-xs font-bold text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-teal-500 outline-none"
          >
            {patients.map(p => (
              <option key={p.id} value={p.id}>
                {p.fullName} ({p.id}) • {p.gender}, {p.age}y
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Selected Patient Banner */}
      {selectedPatient && (
        <div className="bg-gradient-to-r from-teal-900 to-slate-900 text-white rounded-2xl p-4 shadow-md flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-teal-600/40 text-teal-200 font-bold flex items-center justify-center text-base border border-teal-400/30">
              {selectedPatient.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base text-white">{selectedPatient.fullName}</span>
                <span className="px-2 py-0.2 rounded bg-teal-500/30 text-teal-200 font-mono text-[11px]">
                  {selectedPatient.id}
                </span>
              </div>
              <p className="text-xs text-teal-200/80 mt-0.5">
                {selectedPatient.gender}, {selectedPatient.age} yrs • Blood Group: <strong className="text-white">{selectedPatient.bloodGroup}</strong> • Scheme: {selectedPatient.hmoProvider.split('/')[0]}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSelectPatientEMR(selectedPatient.id)}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold border border-white/20 transition-colors"
            >
              View Full EMR History ({previousPatientRecords.length} visits) →
            </button>
          </div>
        </div>
      )}

      {/* Success Notification */}
      {savedSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5 shadow-sm animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>
            <strong>Consultation Saved Successfully!</strong> EMR record, diagnoses, and electronic prescriptions have been synchronized to Chidicon Cloud database.
          </span>
        </div>
      )}

      {/* Main Consultation Form */}
      <form onSubmit={handleSaveConsultation} className="space-y-6">
        
        {/* Section 1: Visit Type & Triage Vitals Confirmation */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs uppercase tracking-wider">
              <Activity className="w-4 h-4 text-teal-600" />
              <span>1. Consultation Metadata & Clinical Vitals</span>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-600">Visit Category:</label>
              <select
                value={visitType}
                onChange={e => setVisitType(e.target.value as any)}
                className="px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none"
              >
                <option value="Outpatient">General Outpatient (GOPD)</option>
                <option value="Follow-up">Follow-up Review</option>
                <option value="Inpatient">Inpatient Ward Round</option>
                <option value="Emergency">Emergency</option>
                <option value="Antenatal">Antenatal Care (ANC)</option>
              </select>
            </div>
          </div>

          {/* Vitals inputs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs">
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Temp (°C)</label>
              <input
                type="number"
                step="0.1"
                value={vitals.temperature}
                onChange={e => setVitals({ ...vitals, temperature: parseFloat(e.target.value) || 37 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">BP Sys (mmHg)</label>
              <input
                type="number"
                value={vitals.bloodPressureSys}
                onChange={e => setVitals({ ...vitals, bloodPressureSys: parseInt(e.target.value) || 120 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">BP Dia (mmHg)</label>
              <input
                type="number"
                value={vitals.bloodPressureDia}
                onChange={e => setVitals({ ...vitals, bloodPressureDia: parseInt(e.target.value) || 80 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Pulse (bpm)</label>
              <input
                type="number"
                value={vitals.pulseRate}
                onChange={e => setVitals({ ...vitals, pulseRate: parseInt(e.target.value) || 75 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Resp Rate (cpm)</label>
              <input
                type="number"
                value={vitals.respiratoryRate}
                onChange={e => setVitals({ ...vitals, respiratoryRate: parseInt(e.target.value) || 18 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Weight (kg)</label>
              <input
                type="number"
                step="0.5"
                value={vitals.weight}
                onChange={e => setVitals({ ...vitals, weight: parseFloat(e.target.value) || 70 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">SpO2 (%)</label>
              <input
                type="number"
                value={vitals.oxygenSaturation}
                onChange={e => setVitals({ ...vitals, oxygenSaturation: parseInt(e.target.value) || 98 })}
                className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 border border-slate-200 font-bold text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Clinical History & Examination */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-900 font-bold text-xs uppercase tracking-wider">
            <Stethoscope className="w-4 h-4 text-emerald-600" />
            <span>2. History & Physical Examination Findings</span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Chief Complaint (Presenting Problem) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. High fever, headache, body aches and loss of appetite for 3 days"
                value={chiefComplaint}
                onChange={e => setChiefComplaint(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                History of Presenting Illness (HPI)
              </label>
              <textarea
                rows={2}
                placeholder="Detailed history: onset, duration, severity, aggravating/relieving factors, previous self-medication..."
                value={historyIllness}
                onChange={e => setHistoryIllness(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Physical Examination Findings (Systemic Review)
              </label>
              <textarea
                rows={2}
                placeholder="General appearance, vitals verification, Chest, CVS, Abdomen (tenderness/organomegaly), CNS findings..."
                value={examinationFindings}
                onChange={e => setExaminationFindings(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Clinical Diagnosis & Treatment Plan */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-900 font-bold text-xs uppercase tracking-wider">
            <BookOpen className="w-4 h-4 text-purple-600" />
            <span>3. Clinical Diagnosis & Treatment Plan</span>
          </div>

          {/* Quick Select Common Tropical Diagnoses */}
          <div>
            <span className="text-[11px] font-bold text-slate-500 block mb-1.5">
              Quick Diagnosis Selector (Common conditions in Owerri clinics):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_DIAGNOSES.map(d => (
                <button
                  type="button"
                  key={d.name}
                  onClick={() => handleSelectPredefinedDiagnosis(d)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition-colors cursor-pointer ${
                    diagnosis === d.name ? 'bg-purple-100 text-purple-900 border-purple-300 font-bold' : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {d.name.split('(')[0]}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Working Diagnosis <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="Enter or select diagnosis..."
                value={diagnosis}
                onChange={e => setDiagnosis(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs font-bold text-slate-900 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ICD-10 Code
              </label>
              <input
                type="text"
                placeholder="e.g. B50.9, I10"
                value={icdCode}
                onChange={e => setIcdCode(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono font-bold text-slate-900 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Treatment Plan & Clinical Directives <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={2}
              required
              placeholder="e.g. Start oral ACT course, administer IV fluids, maintain bed rest, dietary sodium restriction..."
              value={treatmentPlan}
              onChange={e => setTreatmentPlan(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
            />
          </div>
        </div>

        {/* Section 4: Electronic Prescriptions (e-Rx) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-xs uppercase tracking-wider">
              <Pill className="w-4 h-4 text-rose-600" />
              <span>4. Electronic Prescription (e-Rx) for Pharmacy</span>
            </div>

            <button
              type="button"
              onClick={handleAddPrescription}
              className="px-3 py-1 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold text-xs flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Medication</span>
            </button>
          </div>

          <div className="space-y-3">
            {prescriptions.map((p, index) => (
              <div key={p.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs items-center">
                <div className="sm:col-span-4">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-0.5">Drug Name</label>
                  <input
                    type="text"
                    value={p.drugName}
                    onChange={e => handleUpdatePrescription(p.id, 'drugName', e.target.value)}
                    placeholder="Medication name"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 font-semibold text-slate-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-0.5">Dosage</label>
                  <input
                    type="text"
                    value={p.dosage}
                    onChange={e => handleUpdatePrescription(p.id, 'dosage', e.target.value)}
                    placeholder="e.g. 500mg"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 font-medium"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-0.5">Frequency</label>
                  <input
                    type="text"
                    value={p.frequency}
                    onChange={e => handleUpdatePrescription(p.id, 'frequency', e.target.value)}
                    placeholder="e.g. TDS (3 times daily)"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-0.5">Duration</label>
                  <input
                    type="text"
                    value={p.duration}
                    onChange={e => handleUpdatePrescription(p.id, 'duration', e.target.value)}
                    placeholder="e.g. 3 days"
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200"
                  />
                </div>

                <div className="sm:col-span-1 flex justify-end">
                  <button
                    type="button"
                    onClick={() => handleRemovePrescription(p.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 5: Laboratory Orders */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-900 font-bold text-xs uppercase tracking-wider">
            <TestTube2 className="w-4 h-4 text-purple-600" />
            <span>5. Order Diagnostic Laboratory Investigations</span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={selectedLabCategory}
              onChange={e => setSelectedLabCategory(e.target.value as any)}
              className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
            >
              <option value="Parasitology">Parasitology</option>
              <option value="Hematology">Hematology</option>
              <option value="Chemical Pathology">Chemical Pathology</option>
              <option value="Microbiology">Microbiology</option>
            </select>

            <select
              value={selectedLabTest}
              onChange={e => setSelectedLabTest(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold"
            >
              <option value="Malaria Parasite (MP) by Thick Film">Malaria Parasite (MP) by Thick Film</option>
              <option value="Full Blood Count (FBC & Differential)">Full Blood Count (FBC & Differential)</option>
              <option value="Serum Electrolytes, Urea & Creatinine (E/U/Cr)">Serum Electrolytes, Urea & Creatinine (E/U/Cr)</option>
              <option value="Fasting Blood Sugar (FBS)">Fasting Blood Sugar (FBS)</option>
              <option value="Urinalysis (Microscopy & Dipstick)">Urinalysis (Microscopy & Dipstick)</option>
              <option value="Widal Agglutination Reaction Test">Widal Agglutination Reaction Test</option>
              <option value="Lipid Profile (Cholesterol, HDL, LDL, Triglycerides)">Lipid Profile</option>
            </select>

            <button
              type="button"
              onClick={handleAddLabTest}
              className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Lab Request</span>
            </button>
          </div>

          {orderedLabs.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-2">
              {orderedLabs.map((l, i) => (
                <span key={i} className="px-3 py-1 rounded-lg bg-purple-50 text-purple-800 border border-purple-200 text-xs font-semibold flex items-center gap-2">
                  <span>{l}</span>
                  <button type="button" onClick={() => handleRemoveLab(l)} className="text-purple-400 hover:text-purple-700">✕</button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Save & Finalize Button */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            className="px-8 py-3 rounded-2xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-sm shadow-xl shadow-teal-700/20 flex items-center gap-2 transition-all hover:scale-102 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Complete & Synchronize EMR to Cloud</span>
          </button>
        </div>

      </form>
    </div>
  );
};
