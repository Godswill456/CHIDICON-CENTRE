import React, { useState } from 'react';
import { 
  Pill, 
  Search, 
  CheckCircle2, 
  Clock, 
  Printer, 
  AlertCircle, 
  Package, 
  TrendingDown,
  User,
  Filter,
  Check
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';

export const PharmacyDispensing: React.FC = () => {
  const { getAllPrescriptions, dispensePrescription } = useHospital();
  const { currentUser } = useAuth();

  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'dispensed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dispenseSuccessToast, setDispenseSuccessToast] = useState<string | null>(null);

  const prescriptionsList = getAllPrescriptions();

  const filtered = prescriptionsList.filter(item => {
    const matchesStatus = filterStatus === 'all' || item.prescription.status === filterStatus;
    const matchesSearch = 
      item.prescription.drugName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.patient && item.patient.fullName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.patient && item.patient.id.toLowerCase().includes(searchTerm.toLowerCase())) ||
      item.record.doctorName.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesStatus && matchesSearch;
  });

  const handleDispense = (recordId: string, prescriptionId: string, drugName: string) => {
    dispensePrescription(recordId, prescriptionId);
    setDispenseSuccessToast(`Successfully dispensed ${drugName}`);
    setTimeout(() => setDispenseSuccessToast(null), 3000);
  };

  const handlePrintLabel = (item: any) => {
    window.print();
  };

  const pendingCount = prescriptionsList.filter(p => p.prescription.status === 'pending').length;
  const dispensedCount = prescriptionsList.filter(p => p.prescription.status === 'dispensed').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header & Pharmacy Stats */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 text-xs font-bold font-mono">
              Module 5 (Sec 3.7.3)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">Chidicon Pharmacy & Therapeutics</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Electronic Pharmacy Dispensing & Medication Orders
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Process doctor prescriptions, verify dosage safety, and track dispensed pharmaceuticals.
          </p>
        </div>

        {/* Stats Badges */}
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-center">
            <span className="text-[10px] font-bold text-amber-700 uppercase block">Pending</span>
            <span className="text-base font-extrabold text-amber-900">{pendingCount}</span>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
            <span className="text-[10px] font-bold text-emerald-700 uppercase block">Fulfilled</span>
            <span className="text-base font-extrabold text-emerald-900">{dispensedCount}</span>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {dispenseSuccessToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 shadow-sm animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{dispenseSuccessToast}</span>
        </div>
      )}

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative flex-1 w-full sm:w-auto">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search medication, patient name, ID, or prescribing doctor..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 text-xs text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-teal-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              filterStatus === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Prescriptions
          </button>
          <button
            onClick={() => setFilterStatus('pending')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              filterStatus === 'pending' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            Pending ({pendingCount})
          </button>
          <button
            onClick={() => setFilterStatus('dispensed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              filterStatus === 'dispensed' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            Dispensed
          </button>
        </div>
      </div>

      {/* Prescriptions Queue Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">Patient & ID</th>
                <th className="py-3 px-4">Prescribed Drug & Dosage</th>
                <th className="py-3 px-4">Regimen & Route</th>
                <th className="py-3 px-4">Prescribing Doctor</th>
                <th className="py-3 px-4">Status & Dispenser</th>
                <th className="py-3 px-4 text-right">Dispense Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length > 0 ? (
                filtered.map(({ prescription, record, patient }) => (
                  <tr key={prescription.id} className="hover:bg-slate-50/80 transition-colors">
                    
                    {/* Patient */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{patient?.fullName || record.patientId}</div>
                      <div className="text-[10px] font-mono text-slate-500">{record.patientId}</div>
                      {patient?.allergies && patient.allergies.length > 0 && !patient.allergies.includes('None Known') && (
                        <div className="text-[10px] text-rose-600 font-bold mt-0.5">
                          ⚠️ Allergy: {patient.allergies.join(', ')}
                        </div>
                      )}
                    </td>

                    {/* Drug & Dosage */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{prescription.drugName}</div>
                      <div className="text-[11px] text-slate-600">{prescription.dosage} • {prescription.duration}</div>
                      <div className="text-[10px] text-slate-500 italic mt-0.5">{prescription.instructions}</div>
                    </td>

                    {/* Regimen & Route */}
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">{prescription.frequency}</div>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                        {prescription.route}
                      </span>
                    </td>

                    {/* Doctor */}
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-900">{record.doctorName}</div>
                      <div className="text-[10px] text-slate-400">{record.date}</div>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-full ${
                        prescription.status === 'dispensed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {prescription.status}
                      </span>
                      {prescription.dispensedBy && (
                        <div className="text-[10px] text-slate-400 mt-1">
                          By: {prescription.dispensedBy} ({prescription.dispensedAt?.split(' ')[0]})
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      {prescription.status === 'pending' ? (
                        <button
                          onClick={() => handleDispense(record.id, prescription.id, prescription.drugName)}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 ml-auto transition-colors cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Dispense Now</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handlePrintLabel({ prescription, patient, record })}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1 ml-auto"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Label Slip</span>
                        </button>
                      )}
                    </td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-slate-400">
                    <Pill className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p>No prescriptions matching the selected filter.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
