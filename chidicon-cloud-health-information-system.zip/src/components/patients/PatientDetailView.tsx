import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Heart, 
  Activity, 
  Calendar, 
  Stethoscope, 
  Pill, 
  TestTube2, 
  FileText, 
  Printer, 
  Phone, 
  MapPin, 
  Shield, 
  AlertTriangle, 
  Plus, 
  CheckCircle2, 
  Clock, 
  User,
  Share2,
  Download
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Patient, VitalSigns } from '../../types';

interface PatientDetailViewProps {
  patientId: string;
  onBack: () => void;
  onStartConsultation: (patient: Patient) => void;
  onBookAppointment: (patient: Patient) => void;
}

export const PatientDetailView: React.FC<PatientDetailViewProps> = ({
  patientId,
  onBack,
  onStartConsultation,
  onBookAppointment,
}) => {
  const { getPatientById, medicalRecords, labTests, addPatientVitals } = useHospital();
  const { currentUser } = useAuth();

  const patient = getPatientById(patientId);

  const [activeTab, setActiveTab] = useState<'summary' | 'vitals' | 'consultations' | 'prescriptions' | 'lab' | 'card'>('summary');
  
  // Vitals Entry Form Modal State
  const [showVitalsModal, setShowVitalsModal] = useState(false);
  const [newVitals, setNewVitals] = useState({
    temperature: 37.0,
    bloodPressureSys: 120,
    bloodPressureDia: 80,
    pulseRate: 76,
    respiratoryRate: 18,
    weight: patient?.vitalsHistory[0]?.weight || 70,
    height: patient?.vitalsHistory[0]?.height || 170,
    oxygenSaturation: 98,
  });

  if (!patient) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
        <p className="text-sm text-slate-500">Patient with ID {patientId} not found in cloud database.</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 rounded-xl bg-teal-700 text-white text-xs font-bold"
        >
          Return to Patient Directory
        </button>
      </div>
    );
  }

  // Filter records and lab tests for this patient
  const patientRecords = medicalRecords.filter(r => r.patientId === patient.id);
  const patientLabTests = labTests.filter(l => l.patientId === patient.id);
  
  const allPrescriptions = patientRecords.flatMap(r => 
    r.prescriptions.map(p => ({ ...p, recordDate: r.date, doctor: r.doctorName }))
  );

  const handleSaveVitals = (e: React.FormEvent) => {
    e.preventDefault();
    const vitalsPayload: VitalSigns = {
      temperature: Number(newVitals.temperature),
      bloodPressureSys: Number(newVitals.bloodPressureSys),
      bloodPressureDia: Number(newVitals.bloodPressureDia),
      pulseRate: Number(newVitals.pulseRate),
      respiratoryRate: Number(newVitals.respiratoryRate),
      weight: Number(newVitals.weight),
      height: Number(newVitals.height),
      oxygenSaturation: Number(newVitals.oxygenSaturation),
      recordedAt: new Date().toLocaleString('en-US', { timeZone: 'Africa/Lagos' }) + ' WAT',
      recordedBy: currentUser.name,
    };
    addPatientVitals(patient.id, vitalsPayload);
    setShowVitalsModal(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 no-print">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-xs transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Patients List</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowVitalsModal(true)}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs border border-slate-200 shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Activity className="w-4 h-4 text-emerald-600" />
            <span>Record Vitals</span>
          </button>

          <button
            onClick={() => onBookAppointment(patient)}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs border border-slate-200 shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Calendar className="w-4 h-4 text-sky-600" />
            <span>Book Appointment</span>
          </button>

          {(currentUser.role === 'admin' || currentUser.role === 'doctor') && (
            <button
              onClick={() => onStartConsultation(patient)}
              className="px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-teal-700/20 transition-all cursor-pointer"
            >
              <Stethoscope className="w-4 h-4" />
              <span>Start Doctor Consultation</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
            title="Print Medical Record"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Patient Master Profile Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-700 to-emerald-800 text-white font-bold text-2xl flex items-center justify-center shrink-0 shadow-lg shadow-teal-800/20">
              {patient.fullName.charAt(0)}
            </div>
            
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  {patient.fullName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800 font-mono font-bold text-xs border border-teal-200">
                  {patient.id}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold">
                  {patient.gender}, {patient.age} yrs
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 pt-1">
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-teal-600" />
                  <strong className="text-slate-800">{patient.phone}</strong>
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{patient.address}, {patient.lga}, Imo State</span>
                </span>
                <span className="flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-indigo-500" />
                  <span>HMO: <strong>{patient.hmoProvider}</strong></span>
                </span>
              </div>
            </div>
          </div>

          {/* Blood & Vitals Highlights Badge */}
          <div className="flex flex-wrap items-center gap-3 self-start lg:self-center">
            <div className="px-3.5 py-2 rounded-2xl bg-rose-50 border border-rose-200 text-center">
              <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider block">Blood Group</span>
              <span className="text-base font-extrabold text-rose-700">{patient.bloodGroup}</span>
              <span className="text-[10px] text-rose-600 block">Genotype: {patient.genotype}</span>
            </div>

            {patient.vitalsHistory[0] && (
              <div className="px-3.5 py-2 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">Latest BP</span>
                <span className="text-base font-extrabold text-emerald-800">
                  {patient.vitalsHistory[0].bloodPressureSys}/{patient.vitalsHistory[0].bloodPressureDia}
                </span>
                <span className="text-[10px] text-emerald-600 block">mmHg</span>
              </div>
            )}
          </div>

        </div>

        {/* Allergy Alert Banner */}
        {patient.allergies && patient.allergies.length > 0 && !patient.allergies.includes('None Known') && !patient.allergies.includes('None Reported') && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50/80 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>
              <strong>Clinical Allergy Warning:</strong> Patient has recorded hypersensitivity to: {patient.allergies.join(', ')}. Exercise caution when prescribing.
            </span>
          </div>
        )}
      </div>

      {/* Tab Navigation Controls */}
      <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 pb-px no-print">
        {[
          { id: 'summary', label: 'Clinical Summary', icon: FileText, count: null },
          { id: 'vitals', label: 'Vital Signs History', icon: Activity, count: patient.vitalsHistory.length },
          { id: 'consultations', label: 'Consultations & EMR', icon: Stethoscope, count: patientRecords.length },
          { id: 'prescriptions', label: 'Prescriptions', icon: Pill, count: allPrescriptions.length },
          { id: 'lab', label: 'Lab Investigations', icon: TestTube2, count: patientLabTests.length },
          { id: 'card', label: 'Official Hospital Card', icon: Printer, count: null },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`
                flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-t-xl transition-all border-b-2 whitespace-nowrap cursor-pointer
                ${isActive 
                  ? 'border-teal-700 text-teal-800 bg-white shadow-xs' 
                  : 'border-transparent text-slate-500 hover:text-slate-900 hover:bg-slate-100/60'
                }
              `}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-teal-700' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.count !== null && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isActive ? 'bg-teal-100 text-teal-800' : 'bg-slate-200 text-slate-600'}`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab 1: Clinical Summary & Patient Details */}
      {activeTab === 'summary' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Demographics & Registration Details */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Bio-Data & Emergency Contact
            </h3>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Date of Birth:</span>
                <span className="font-semibold text-slate-900">{patient.dateOfBirth}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Marital Status:</span>
                <span className="font-semibold text-slate-900">{patient.maritalStatus}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Occupation:</span>
                <span className="font-semibold text-slate-900">{patient.occupation}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">City / LGA:</span>
                <span className="font-semibold text-slate-900">{patient.lga}, {patient.state}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Registered On:</span>
                <span className="font-semibold text-slate-900">{patient.registeredAt}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-slate-500">Registered By:</span>
                <span className="font-semibold text-slate-900">{patient.registeredBy}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Next of Kin / Emergency:
              </span>
              <div className="mt-1.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div className="font-bold text-slate-900">{patient.emergencyContact.name}</div>
                <div className="text-slate-500">{patient.emergencyContact.relationship}</div>
                <div className="text-teal-700 font-medium mt-1">{patient.emergencyContact.phone}</div>
              </div>
            </div>
          </div>

          {/* Clinical History & Chronic Conditions */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider pb-3 border-b border-slate-100">
                Chronic Medical Profile & Diagnoses
              </h3>

              <div className="mt-4 space-y-3">
                <div>
                  <span className="text-xs font-semibold text-slate-500 block mb-1">Documented Chronic Conditions:</span>
                  <div className="flex flex-wrap gap-2">
                    {patient.chronicConditions.length > 0 ? (
                      patient.chronicConditions.map((cond, i) => (
                        <span key={i} className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bold">
                          {cond}
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-slate-400 italic">None recorded</span>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 block mb-1">Recent Hospital Visits & Diagnoses:</span>
                  {patientRecords.length > 0 ? (
                    <div className="space-y-2 mt-2">
                      {patientRecords.map(rec => (
                        <div key={rec.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-emerald-800">{rec.diagnosis}</span>
                            <span className="text-slate-400 text-[11px]">{rec.date}</span>
                          </div>
                          <p className="text-slate-600 mt-1"><strong>Doctor:</strong> {rec.doctorName} • <strong>Type:</strong> {rec.visitType}</p>
                          <p className="text-slate-600 mt-0.5"><strong>Plan:</strong> {rec.treatmentPlan}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 italic">No previous consultation records in database.</p>
                  )}
                </div>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Tab 2: Vital Signs History */}
      {activeTab === 'vitals' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Vital Signs Tracking Chart</h3>
              <p className="text-xs text-slate-500">Blood pressure, body temperature, pulse, respiratory rate & weight history</p>
            </div>
            <button
              onClick={() => setShowVitalsModal(true)}
              className="px-3 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log New Vitals</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="py-2.5 px-3">Date & Time</th>
                  <th className="py-2.5 px-3">BP (mmHg)</th>
                  <th className="py-2.5 px-3">Temp (°C)</th>
                  <th className="py-2.5 px-3">Pulse Rate</th>
                  <th className="py-2.5 px-3">Resp Rate</th>
                  <th className="py-2.5 px-3">Weight / Height</th>
                  <th className="py-2.5 px-3">Recorded By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {patient.vitalsHistory.length > 0 ? (
                  patient.vitalsHistory.map((v, i) => (
                    <tr key={i} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-semibold text-slate-900">{v.recordedAt}</td>
                      <td className="py-3 px-3">
                        <span className={`font-bold px-2 py-0.5 rounded ${
                          v.bloodPressureSys >= 140 || v.bloodPressureDia >= 90 ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-700'
                        }`}>
                          {v.bloodPressureSys} / {v.bloodPressureDia}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`font-bold ${v.temperature >= 38.0 ? 'text-rose-600' : 'text-slate-800'}`}>
                          {v.temperature}°C
                        </span>
                      </td>
                      <td className="py-3 px-3">{v.pulseRate} bpm</td>
                      <td className="py-3 px-3">{v.respiratoryRate} cpm</td>
                      <td className="py-3 px-3">{v.weight} kg {v.height ? `(${v.height} cm)` : ''}</td>
                      <td className="py-3 px-3 text-slate-500">{v.recordedBy}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No vitals recorded yet. Click "Log New Vitals" above.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Consultations & EMR Notes */}
      {activeTab === 'consultations' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Clinical Consultation Notes</h3>
            {(currentUser.role === 'admin' || currentUser.role === 'doctor') && (
              <button
                onClick={() => onStartConsultation(patient)}
                className="px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Doctor Consultation</span>
              </button>
            )}
          </div>

          {patientRecords.length > 0 ? (
            patientRecords.map(rec => (
              <div key={rec.id} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-xs">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-700 font-mono font-bold text-xs">
                      {rec.id}
                    </span>
                    <span className="text-xs font-bold text-slate-800">{rec.doctorName}</span>
                    <span className="text-slate-400 text-xs">•</span>
                    <span className="text-xs text-slate-500">{rec.visitType}</span>
                  </div>
                  <span className="text-xs text-slate-400">{rec.date}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div>
                    <strong className="text-slate-700 block mb-0.5">Chief Complaint:</strong>
                    <p className="text-slate-600 bg-slate-50 p-2.5 rounded-xl">{rec.chiefComplaint}</p>
                  </div>
                  <div>
                    <strong className="text-slate-700 block mb-0.5">History of Presenting Illness:</strong>
                    <p className="text-slate-600 bg-slate-50 p-2.5 rounded-xl">{rec.historyOfPresentingIllness}</p>
                  </div>
                  <div className="md:col-span-2">
                    <strong className="text-slate-700 block mb-0.5">Examination Findings:</strong>
                    <p className="text-slate-600 bg-slate-50 p-2.5 rounded-xl">{rec.examinationFindings}</p>
                  </div>
                  <div className="md:col-span-2">
                    <div className="flex items-center gap-2">
                      <strong className="text-slate-900">Diagnosis:</strong>
                      <span className="px-2.5 py-0.5 rounded bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                        {rec.diagnosis} {rec.icdCode ? `(ICD-10: ${rec.icdCode})` : ''}
                      </span>
                    </div>
                    <p className="text-slate-700 mt-2 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100">
                      <strong>Treatment Plan:</strong> {rec.treatmentPlan}
                    </p>
                  </div>
                </div>

                {rec.prescriptions.length > 0 && (
                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      Prescribed Medications:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {rec.prescriptions.map(p => (
                        <div key={p.id} className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                          <div>
                            <div className="font-bold text-slate-900">{p.drugName}</div>
                            <div className="text-[11px] text-slate-500">{p.dosage} • {p.frequency} ({p.duration})</div>
                          </div>
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                            p.status === 'dispensed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {p.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 text-xs">
              No consultation records logged yet for this patient.
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Prescriptions */}
      {activeTab === 'prescriptions' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Patient Electronic Prescriptions (e-Rx)</h3>
              <p className="text-xs text-slate-500">History of medications prescribed and pharmacy dispensing state</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="py-2.5 px-3">Date Prescribed</th>
                  <th className="py-2.5 px-3">Medication Name</th>
                  <th className="py-2.5 px-3">Dosage & Regimen</th>
                  <th className="py-2.5 px-3">Duration & Route</th>
                  <th className="py-2.5 px-3">Doctor</th>
                  <th className="py-2.5 px-3">Pharmacy Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {allPrescriptions.length > 0 ? (
                  allPrescriptions.map((rx, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-3 px-3 text-slate-500 whitespace-nowrap">{rx.recordDate}</td>
                      <td className="py-3 px-3 font-bold text-slate-900">{rx.drugName}</td>
                      <td className="py-3 px-3 font-medium text-slate-700">{rx.dosage} • {rx.frequency}</td>
                      <td className="py-3 px-3">{rx.duration} ({rx.route})</td>
                      <td className="py-3 px-3 text-slate-600">{rx.doctor}</td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-full ${
                          rx.status === 'dispensed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {rx.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No prescriptions on record.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 5: Diagnostic Laboratory */}
      {activeTab === 'lab' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Laboratory Investigations & Results</h3>
              <p className="text-xs text-slate-500">Hematology, parasitology, microbiology, and clinical pathology tests</p>
            </div>
          </div>

          <div className="space-y-3">
            {patientLabTests.length > 0 ? (
              patientLabTests.map(test => (
                <div key={test.id} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{test.testName}</span>
                      <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px] font-bold">
                        {test.category}
                      </span>
                    </div>
                    <span className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full ${
                      test.status === 'completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {test.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="text-slate-500 flex items-center gap-4 text-[11px]">
                    <span>Requested by: <strong>{test.doctorName}</strong></span>
                    <span>Date: {test.requestDate}</span>
                    <span>Priority: <strong>{test.priority}</strong></span>
                  </div>

                  {test.results && (
                    <div className="mt-2 p-3 rounded-lg bg-white border border-slate-200">
                      <strong className="text-slate-900 block mb-0.5">Laboratory Findings & Diagnostic Values:</strong>
                      <p className="text-slate-700 font-mono text-xs">{test.results}</p>
                      {test.scientistNotes && (
                        <p className="text-slate-500 text-[11px] mt-1 italic">
                          Scientist note: {test.scientistNotes}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-slate-400 text-xs">
                No laboratory investigations ordered for this patient.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 6: Official Hospital Electronic Card */}
      {activeTab === 'card' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between no-print">
            <h3 className="text-sm font-bold text-slate-900">Official Electronic Patient Hospital Card</h3>
            <button
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              <span>Print Hospital Card</span>
            </button>
          </div>

          <div className="print-card max-w-xl mx-auto bg-gradient-to-br from-teal-900 via-teal-800 to-slate-900 text-white rounded-3xl p-6 text-left shadow-2xl border border-teal-600/40 relative overflow-hidden">
            <div className="flex items-start justify-between border-b border-teal-500/30 pb-4">
              <div>
                <div className="text-xs font-bold text-teal-300 uppercase tracking-wider">
                  CHIDICON MEDICAL CENTRE, OWERRI
                </div>
                <div className="text-xs text-teal-100/70">Health Information Management System (Cloud EMR)</div>
              </div>
              <div className="px-2.5 py-1 rounded-lg bg-teal-500/30 border border-teal-400/40 text-xs font-mono font-bold text-teal-200">
                {patient.id}
              </div>
            </div>

            <div className="mt-5 space-y-4">
              <div>
                <div className="text-[11px] uppercase tracking-wider text-teal-300">Patient Full Name</div>
                <div className="text-xl font-bold text-white tracking-tight">{patient.fullName}</div>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-1 text-xs">
                <div>
                  <span className="text-[10px] text-teal-300 block uppercase">Age / Gender</span>
                  <span className="font-semibold text-white">{patient.age} yrs • {patient.gender}</span>
                </div>
                <div>
                  <span className="text-[10px] text-teal-300 block uppercase">Blood Group</span>
                  <span className="font-bold text-teal-200">{patient.bloodGroup} (Genotype: {patient.genotype})</span>
                </div>
                <div>
                  <span className="text-[10px] text-teal-300 block uppercase">HMO / Scheme</span>
                  <span className="font-semibold truncate block text-white">{patient.hmoProvider.split('/')[0]}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-teal-500/30 text-xs space-y-1 text-teal-100">
                <div><strong>Address:</strong> {patient.address}, {patient.lga}, Imo State</div>
                <div><strong>Phone:</strong> {patient.phone}</div>
                <div><strong>Emergency Contact:</strong> {patient.emergencyContact.name} ({patient.emergencyContact.phone})</div>
              </div>

              <div className="pt-3 border-t border-teal-500/30 flex items-center justify-between text-[10px] text-teal-300">
                <span>Hospital Node: Owerri Municipal Cluster</span>
                <span>Issue Date: {patient.registeredAt}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Record New Vitals */}
      {showVitalsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <Activity className="w-4 h-4 text-emerald-600" />
                <span>Log Vital Signs for {patient.fullName}</span>
              </div>
              <button onClick={() => setShowVitalsModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveVitals} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Temperature (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={newVitals.temperature}
                    onChange={e => setNewVitals({ ...newVitals, temperature: parseFloat(e.target.value) || 37 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pulse Rate (bpm)</label>
                  <input
                    type="number"
                    required
                    value={newVitals.pulseRate}
                    onChange={e => setNewVitals({ ...newVitals, pulseRate: parseInt(e.target.value) || 75 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Systolic BP (mmHg)</label>
                  <input
                    type="number"
                    required
                    value={newVitals.bloodPressureSys}
                    onChange={e => setNewVitals({ ...newVitals, bloodPressureSys: parseInt(e.target.value) || 120 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Diastolic BP (mmHg)</label>
                  <input
                    type="number"
                    required
                    value={newVitals.bloodPressureDia}
                    onChange={e => setNewVitals({ ...newVitals, bloodPressureDia: parseInt(e.target.value) || 80 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={newVitals.weight}
                    onChange={e => setNewVitals({ ...newVitals, weight: parseFloat(e.target.value) || 70 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">SpO2 Oxygen (%)</label>
                  <input
                    type="number"
                    value={newVitals.oxygenSaturation}
                    onChange={e => setNewVitals({ ...newVitals, oxygenSaturation: parseInt(e.target.value) || 98 })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowVitalsModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold shadow-md shadow-teal-700/20"
                >
                  Save Vitals to EMR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
