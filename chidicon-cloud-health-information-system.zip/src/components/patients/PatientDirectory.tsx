import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  UserPlus, 
  ChevronRight, 
  Phone, 
  MapPin, 
  Heart, 
  Shield, 
  Activity, 
  Printer, 
  Calendar,
  Grid,
  List,
  FolderHeart,
  Droplet
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Patient } from '../../types';

interface PatientDirectoryProps {
  onSelectPatient: (patientId: string) => void;
  onOpenNewRegistration: () => void;
  onOpenBookAppointment: (patient: Patient) => void;
}

export const PatientDirectory: React.FC<PatientDirectoryProps> = ({
  onSelectPatient,
  onOpenNewRegistration,
  onOpenBookAppointment,
}) => {
  const { patients } = useHospital();
  const { currentUser } = useAuth();

  const [searchTerm, setSearchTerm] = useState('');
  const [lgaFilter, setLgaFilter] = useState('all');
  const [bloodGroupFilter, setBloodGroupFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Filter patients
  const filteredPatients = patients.filter(patient => {
    const matchesSearch = 
      patient.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.phone.includes(searchTerm) ||
      patient.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (patient.chronicConditions && patient.chronicConditions.some(c => c.toLowerCase().includes(searchTerm.toLowerCase())));

    const matchesLga = lgaFilter === 'all' || patient.lga === lgaFilter;
    const matchesBlood = bloodGroupFilter === 'all' || patient.bloodGroup === bloodGroupFilter;

    return matchesSearch && matchesLga && matchesBlood;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Module Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-700 text-xs font-bold font-mono">
              Module 2 (Sec 3.6.2)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">{patients.length} Registered Electronic Files</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Patient Records & Electronic Medical Directory
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Search, retrieve, and review electronic health records for Chidicon Medical Centre.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {(currentUser.role === 'admin' || currentUser.role === 'receptionist' || currentUser.role === 'nurse') && (
            <button
              onClick={onOpenNewRegistration}
              className="px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-2 shadow-sm shadow-teal-700/20 transition-all cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register New Patient</span>
            </button>
          )}

          {/* View Toggle */}
          <div className="hidden sm:flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs transition-colors ${viewMode === 'table' ? 'bg-white shadow-xs text-teal-700 font-bold' : 'text-slate-500'}`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-lg text-xs transition-colors ${viewMode === 'cards' ? 'bg-white shadow-xs text-teal-700 font-bold' : 'text-slate-500'}`}
              title="Card View"
            >
              <Grid className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search by Patient Name, ID (CMC-2026-XXXX), Phone, Address, or Diagnosis..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white text-xs text-slate-900 placeholder-slate-400 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          {/* LGA Filter */}
          <select
            value={lgaFilter}
            onChange={e => setLgaFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 text-xs text-slate-700 font-medium rounded-xl border border-slate-200 focus:border-teal-500 outline-none w-full sm:w-auto"
          >
            <option value="all">All LGAs in Imo</option>
            <option value="Owerri Municipal">Owerri Municipal</option>
            <option value="Owerri North">Owerri North</option>
            <option value="Owerri West">Owerri West</option>
            <option value="Mbaitoli">Mbaitoli</option>
            <option value="Ikeduru">Ikeduru</option>
          </select>

          {/* Blood Group Filter */}
          <select
            value={bloodGroupFilter}
            onChange={e => setBloodGroupFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 text-xs text-slate-700 font-medium rounded-xl border border-slate-200 focus:border-teal-500 outline-none w-full sm:w-auto"
          >
            <option value="all">All Blood Groups</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="AB+">AB+</option>
          </select>

          {(searchTerm || lgaFilter !== 'all' || bloodGroupFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setLgaFilter('all');
                setBloodGroupFilter('all');
              }}
              className="px-3 py-2 text-xs font-semibold text-rose-600 hover:text-rose-800 shrink-0"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Patient List Content */}
      {viewMode === 'table' ? (
        /* Table View */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Patient ID & Name</th>
                  <th className="py-3.5 px-4">Age / Sex</th>
                  <th className="py-3.5 px-4">Contact & Location</th>
                  <th className="py-3.5 px-4">Blood Profile</th>
                  <th className="py-3.5 px-4">HMO / Scheme</th>
                  <th className="py-3.5 px-4">Latest Vitals</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredPatients.length > 0 ? (
                  filteredPatients.map(patient => {
                    const latestVitals = patient.vitalsHistory[0];
                    return (
                      <tr 
                        key={patient.id} 
                        className="hover:bg-teal-50/40 transition-colors group cursor-pointer"
                        onClick={() => onSelectPatient(patient.id)}
                      >
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 font-bold flex items-center justify-center shrink-0 group-hover:bg-teal-700 group-hover:text-white transition-colors">
                              {patient.fullName.charAt(0)}
                            </div>
                            <div>
                              <div className="font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                                {patient.fullName}
                              </div>
                              <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                                {patient.id}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="font-semibold">{patient.gender}</span>, {patient.age} yrs
                          <span className="block text-[10px] text-slate-400">DOB: {patient.dateOfBirth}</span>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="font-medium text-slate-900">{patient.phone}</div>
                          <div className="text-[11px] text-slate-500 truncate max-w-xs flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                            <span>{patient.lga}, Imo State</span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <span className="px-2 py-0.5 rounded bg-rose-50 border border-rose-200 text-rose-700 font-bold text-[11px]">
                              {patient.bloodGroup}
                            </span>
                            <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-medium text-[10px]">
                              {patient.genotype}
                            </span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-medium inline-block truncate max-w-[140px]">
                            {patient.hmoProvider.split('(')[0]}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 whitespace-nowrap">
                          {latestVitals ? (
                            <div>
                              <span className="font-bold text-slate-800">
                                {latestVitals.bloodPressureSys}/{latestVitals.bloodPressureDia} mmHg
                              </span>
                              <span className="text-[10px] text-slate-500 block">
                                {latestVitals.temperature}°C • {latestVitals.pulseRate} bpm
                              </span>
                            </div>
                          ) : (
                            <span className="text-slate-400 italic text-[11px]">No vitals yet</span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={e => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => onSelectPatient(patient.id)}
                              className="px-2.5 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-700 hover:text-white text-teal-700 font-bold text-xs transition-colors"
                            >
                              EMR Chart →
                            </button>
                            <button
                              onClick={() => onOpenBookAppointment(patient)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                              title="Book Appointment"
                            >
                              <Calendar className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500">
                      <FolderHeart className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs">No matching patient files found.</p>
                      <button
                        onClick={onOpenNewRegistration}
                        className="mt-3 text-xs font-bold text-teal-700 hover:underline"
                      >
                        + Register new patient
                      </button>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Cards View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPatients.map(patient => (
            <div
              key={patient.id}
              onClick={() => onSelectPatient(patient.id)}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-sm group-hover:bg-teal-700 group-hover:text-white transition-colors">
                      {patient.fullName.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm group-hover:text-teal-700 transition-colors">
                        {patient.fullName}
                      </h3>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                        {patient.id}
                      </span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 text-xs font-bold border border-rose-200">
                    {patient.bloodGroup}
                  </span>
                </div>

                <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Demographics:</span>
                    <span className="font-semibold">{patient.gender}, {patient.age} years</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Phone:</span>
                    <span className="font-medium text-slate-900">{patient.phone}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Location:</span>
                    <span className="truncate max-w-[140px]">{patient.lga}, Imo</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Scheme:</span>
                    <span className="truncate max-w-[140px] text-teal-700 font-medium">{patient.hmoProvider.split('/')[0]}</span>
                  </div>
                </div>

                {patient.chronicConditions.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Conditions:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {patient.chronicConditions.map((c, i) => (
                        <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">Reg: {patient.registeredAt}</span>
                <span className="font-bold text-teal-700 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                  <span>Open EMR</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
