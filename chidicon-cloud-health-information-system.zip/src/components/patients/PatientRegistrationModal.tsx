import React, { useState } from 'react';
import { 
  X, 
  UserPlus, 
  CheckCircle2, 
  AlertCircle, 
  Heart, 
  Shield, 
  Phone, 
  MapPin, 
  Calendar,
  CreditCard,
  User,
  FileText,
  Printer
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Patient, VitalSigns } from '../../types';

interface PatientRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (patient: Patient) => void;
}

export const PatientRegistrationModal: React.FC<PatientRegistrationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { registerPatient, patients } = useHospital();
  const { currentUser } = useAuth();

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    dateOfBirth: '1995-05-15',
    gender: 'Male' as 'Male' | 'Female' | 'Other',
    phone: '+234 ',
    email: '',
    address: '',
    city: 'Owerri',
    lga: 'Owerri Municipal',
    state: 'Imo State',
    occupation: '',
    maritalStatus: 'Single' as 'Single' | 'Married' | 'Widowed' | 'Divorced',
    bloodGroup: 'O+' as Patient['bloodGroup'],
    genotype: 'AA' as Patient['genotype'],
    allergies: '',
    chronicConditions: '',
    emergencyName: '',
    emergencyRelationship: 'Next of Kin / Spouse',
    emergencyPhone: '+234 ',
    hmoProvider: 'Private / Self-Pay',
    hmoNumber: '',
    notes: '',
  });

  // Optional Initial Triage Vitals
  const [includeVitals, setIncludeVitals] = useState(false);
  const [vitalsData, setVitalsData] = useState({
    temperature: 36.8,
    bloodPressureSys: 120,
    bloodPressureDia: 80,
    pulseRate: 75,
    respiratoryRate: 18,
    weight: 70.0,
    height: 170,
    oxygenSaturation: 99,
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);
  const [registeredPatient, setRegisteredPatient] = useState<Patient | null>(null);

  if (!isOpen) return null;

  // Calculate age from DOB
  const calculateAge = (dob: string): number => {
    if (!dob) return 0;
    const birthDate = new Date(dob);
    const difference = Date.now() - birthDate.getTime();
    const ageDate = new Date(difference);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  };

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.fullName.trim() || formData.fullName.trim().split(' ').length < 2) {
      newErrors.fullName = 'Please enter at least Surname and First Name.';
    }

    if (!formData.dateOfBirth) {
      newErrors.dateOfBirth = 'Date of birth is required.';
    }

    if (!formData.phone.trim() || formData.phone.trim().length < 10) {
      newErrors.phone = 'Valid phone number is required (e.g. +234 803 123 4567).';
    }

    if (!formData.address.trim()) {
      newErrors.address = 'Residential street address in Owerri is required.';
    }

    if (!formData.emergencyName.trim()) {
      newErrors.emergencyName = 'Emergency contact person is required.';
    }

    if (!formData.emergencyPhone.trim() || formData.emergencyPhone.trim().length < 10) {
      newErrors.emergencyPhone = 'Emergency contact phone number is required.';
    }

    // Check existing record duplicate (Program Flowchart Sec 3.6.4)
    const existing = patients.find(
      p => p.fullName.toLowerCase() === formData.fullName.trim().toLowerCase() ||
           p.phone.replace(/\s+/g, '') === formData.phone.replace(/\s+/g, '')
    );

    if (existing) {
      setDuplicateWarning(`Note: A patient record with matching name/phone already exists: ${existing.fullName} (${existing.id}). Proceed if this is a distinct patient.`);
    } else {
      setDuplicateWarning(null);
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const age = calculateAge(formData.dateOfBirth);

    const allergiesArr = formData.allergies.trim() 
      ? formData.allergies.split(',').map(s => s.trim()).filter(Boolean)
      : ['None Reported'];

    const chronicArr = formData.chronicConditions.trim()
      ? formData.chronicConditions.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    let initialVitals: VitalSigns | undefined = undefined;
    if (includeVitals) {
      initialVitals = {
        temperature: Number(vitalsData.temperature),
        bloodPressureSys: Number(vitalsData.bloodPressureSys),
        bloodPressureDia: Number(vitalsData.bloodPressureDia),
        pulseRate: Number(vitalsData.pulseRate),
        respiratoryRate: Number(vitalsData.respiratoryRate),
        weight: Number(vitalsData.weight),
        height: Number(vitalsData.height),
        oxygenSaturation: Number(vitalsData.oxygenSaturation),
        recordedAt: new Date().toLocaleString('en-US', { timeZone: 'Africa/Lagos' }) + ' WAT',
        recordedBy: currentUser.name,
      };
    }

    const patient = registerPatient({
      fullName: formData.fullName.trim(),
      dateOfBirth: formData.dateOfBirth,
      age,
      gender: formData.gender,
      phone: formData.phone.trim(),
      email: formData.email.trim() || undefined,
      address: formData.address.trim(),
      city: formData.city.trim() || 'Owerri',
      lga: formData.lga,
      state: formData.state,
      occupation: formData.occupation.trim() || 'Unspecified',
      maritalStatus: formData.maritalStatus,
      bloodGroup: formData.bloodGroup,
      genotype: formData.genotype,
      allergies: allergiesArr,
      chronicConditions: chronicArr,
      emergencyContact: {
        name: formData.emergencyName.trim(),
        relationship: formData.emergencyRelationship.trim(),
        phone: formData.emergencyPhone.trim(),
      },
      hmoProvider: formData.hmoProvider,
      hmoNumber: formData.hmoNumber.trim() || undefined,
      notes: formData.notes.trim() || undefined,
    }, initialVitals);

    setRegisteredPatient(patient);
    onSuccess(patient);
  };

  const handlePrintCard = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[92vh] overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-teal-800 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-600/40 border border-teal-400/30 flex items-center justify-center text-teal-200">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">New Patient Registration</h2>
              <p className="text-xs text-teal-200/80">
                Chidicon Medical Centre, Owerri • Input Specification (Sec 3.7.1)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-teal-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content / Confirmation Card */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {registeredPatient ? (
            /* Registration Success Screen with Printable Hospital Card */
            <div className="space-y-6 text-center py-4">
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/10">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900">Patient Successfully Registered!</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Electronic health record created in Chidicon Cloud Database.
                </p>
              </div>

              {/* Printable Official Hospital Card */}
              <div className="print-card max-w-md mx-auto bg-gradient-to-br from-teal-900 via-teal-800 to-slate-900 text-white rounded-2xl p-5 text-left shadow-xl border border-teal-600/40 relative overflow-hidden">
                <div className="flex items-start justify-between border-b border-teal-500/30 pb-3">
                  <div>
                    <div className="text-[10px] font-bold text-teal-300 uppercase tracking-wider">
                      CHIDICON MEDICAL CENTRE, OWERRI
                    </div>
                    <div className="text-xs text-teal-100/70">Official Patient Electronic Health Card</div>
                  </div>
                  <div className="px-2 py-1 rounded bg-teal-500/30 border border-teal-400/40 text-[11px] font-mono font-bold text-teal-200">
                    {registeredPatient.id}
                  </div>
                </div>

                <div className="mt-4 space-y-2">
                  <div>
                    <div className="text-[10px] uppercase text-teal-300">Patient Full Name</div>
                    <div className="text-base font-bold text-white tracking-tight">{registeredPatient.fullName}</div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                    <div>
                      <span className="text-[10px] text-teal-300 block">Gender/Age</span>
                      <span className="font-semibold">{registeredPatient.gender}, {registeredPatient.age}y</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-teal-300 block">Blood Group</span>
                      <span className="font-semibold text-teal-200">{registeredPatient.bloodGroup} (Genotype: {registeredPatient.genotype})</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-teal-300 block">HMO/Insurance</span>
                      <span className="font-semibold truncate block">{registeredPatient.hmoProvider.split('/')[0]}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-teal-500/30 flex items-center justify-between text-[10px] text-teal-200/80">
                    <span>Emergency Contact: {registeredPatient.emergencyContact.phone}</span>
                    <span>Reg Date: {registeredPatient.registeredAt}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2 no-print">
                <button
                  onClick={handlePrintCard}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Hospital Card</span>
                </button>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs shadow-md shadow-teal-800/20"
                >
                  Done & Go to Records
                </button>
              </div>
            </div>
          ) : (
            /* Registration Form */
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Duplicate Warning if detected */}
              {duplicateWarning && (
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>{duplicateWarning}</span>
                </div>
              )}

              {/* Section 1: Demographics */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-800 font-bold text-xs uppercase tracking-wider">
                  <User className="w-4 h-4 text-teal-600" />
                  <span>1. Patient Demographics & Bio-Data</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Full Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Full Name (Surname First, Other Names) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Obi, Chidiebere Stanley"
                      value={formData.fullName}
                      onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 text-xs text-slate-900 outline-none"
                    />
                    {errors.fullName && <p className="text-[11px] text-rose-500 mt-1">{errors.fullName}</p>}
                  </div>

                  {/* DOB */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Date of Birth <span className="text-rose-500">*</span> (Age: {calculateAge(formData.dateOfBirth)} yrs)
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.dateOfBirth}
                      onChange={e => setFormData({ ...formData, dateOfBirth: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 text-xs text-slate-900 outline-none"
                    />
                  </div>

                  {/* Gender */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Gender <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={formData.gender}
                      onChange={e => setFormData({ ...formData, gender: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Phone Number <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+234 803 000 0000"
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                    {errors.phone && <p className="text-[11px] text-rose-500 mt-1">{errors.phone}</p>}
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      placeholder="patient@example.com"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                  </div>

                  {/* Address */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Residential Street Address <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 14 Ikenegbu Layout, Off Wetheral Road"
                      value={formData.address}
                      onChange={e => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                    {errors.address && <p className="text-[11px] text-rose-500 mt-1">{errors.address}</p>}
                  </div>

                  {/* LGA & City */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      L.G.A in Imo State <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={formData.lga}
                      onChange={e => setFormData({ ...formData, lga: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    >
                      <option value="Owerri Municipal">Owerri Municipal</option>
                      <option value="Owerri North">Owerri North (Uratta, Egbu, Emekuku)</option>
                      <option value="Owerri West">Owerri West (Umuguma, Nekede, Ihiagwa)</option>
                      <option value="Mbaitoli">Mbaitoli</option>
                      <option value="Ikeduru">Ikeduru</option>
                      <option value="Ngor Okpala">Ngor Okpala</option>
                      <option value="Aboh Mbaise">Aboh Mbaise</option>
                      <option value="Ohaji/Egbema">Ohaji/Egbema</option>
                      <option value="Oguta">Oguta</option>
                      <option value="Orlu">Orlu</option>
                      <option value="Other LGA">Other LGA in Imo</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Occupation
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Civil Servant, Trader, Teacher"
                      value={formData.occupation}
                      onChange={e => setFormData({ ...formData, occupation: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                  </div>

                </div>
              </div>

              {/* Section 2: Clinical Baseline & Blood Profile */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-800 font-bold text-xs uppercase tracking-wider">
                  <Heart className="w-4 h-4 text-rose-600" />
                  <span>2. Clinical Blood Profile & Medical History</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Blood Group
                    </label>
                    <select
                      value={formData.bloodGroup}
                      onChange={e => setFormData({ ...formData, bloodGroup: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none font-bold"
                    >
                      <option value="O+">O+ (Universal Donor)</option>
                      <option value="O-">O-</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Genotype
                    </label>
                    <select
                      value={formData.genotype}
                      onChange={e => setFormData({ ...formData, genotype: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none font-bold"
                    >
                      <option value="AA">AA (Normal)</option>
                      <option value="AS">AS (Sickle Trait)</option>
                      <option value="SS">SS (Sickle Cell Disease)</option>
                      <option value="AC">AC</option>
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Drug Allergies / Adverse Reactions
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Penicillin, Sulpha drugs (or None)"
                      value={formData.allergies}
                      onChange={e => setFormData({ ...formData, allergies: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                  </div>

                  <div className="sm:col-span-4">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Chronic Medical Conditions (if any)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Hypertension, Type 2 Diabetes, Asthma, Peptic Ulcer"
                      value={formData.chronicConditions}
                      onChange={e => setFormData({ ...formData, chronicConditions: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Next of Kin & HMO Billing */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-100 text-slate-800 font-bold text-xs uppercase tracking-wider">
                  <Shield className="w-4 h-4 text-indigo-600" />
                  <span>3. Next of Kin & Insurance / Billing Category</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Next of Kin Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Full Name"
                      value={formData.emergencyName}
                      onChange={e => setFormData({ ...formData, emergencyName: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                    {errors.emergencyName && <p className="text-[11px] text-rose-500 mt-1">{errors.emergencyName}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Relationship
                    </label>
                    <input
                      type="text"
                      placeholder="Spouse, Father, Mother, Sibling"
                      value={formData.emergencyRelationship}
                      onChange={e => setFormData({ ...formData, emergencyRelationship: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Next of Kin Phone <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+234 800 000 0000"
                      value={formData.emergencyPhone}
                      onChange={e => setFormData({ ...formData, emergencyPhone: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                    {errors.emergencyPhone && <p className="text-[11px] text-rose-500 mt-1">{errors.emergencyPhone}</p>}
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Billing Scheme / HMO Provider
                    </label>
                    <select
                      value={formData.hmoProvider}
                      onChange={e => setFormData({ ...formData, hmoProvider: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    >
                      <option value="Private / Self-Pay">Private / Self-Pay (Out of Pocket)</option>
                      <option value="Imo Health Insurance (ImoCare)">Imo State Health Insurance Scheme (ImoCare)</option>
                      <option value="Hygeia HMO">Hygeia HMO</option>
                      <option value="AXA Mansard Health">AXA Mansard Health</option>
                      <option value="Leadway Health">Leadway Health</option>
                      <option value="Reliance HMO">Reliance HMO</option>
                      <option value="NHIS Corporate">National Health Insurance Scheme (NHIS)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Enrollee Policy Number
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. IMC-2026-991"
                      value={formData.hmoNumber}
                      onChange={e => setFormData({ ...formData, hmoNumber: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-teal-500 text-xs text-slate-900 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Optional Section 4: Initial Triage Vitals on Registration */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                    <input
                      type="checkbox"
                      id="vitalsCheck"
                      checked={includeVitals}
                      onChange={e => setIncludeVitals(e.target.checked)}
                      className="w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
                    />
                    <label htmlFor="vitalsCheck" className="cursor-pointer">
                      Record Initial Triage Vital Signs Now (Optional)
                    </label>
                  </div>
                  <span className="text-[10px] text-slate-500">Nurse Triage</span>
                </div>

                {includeVitals && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600">Temp (°C)</label>
                      <input
                        type="number"
                        step="0.1"
                        value={vitalsData.temperature}
                        onChange={e => setVitalsData({ ...vitalsData, temperature: parseFloat(e.target.value) || 37 })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600">BP (mmHg)</label>
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          placeholder="Sys"
                          value={vitalsData.bloodPressureSys}
                          onChange={e => setVitalsData({ ...vitalsData, bloodPressureSys: parseInt(e.target.value) || 120 })}
                          className="w-full px-2 py-1.5 rounded-lg bg-white border border-slate-200 text-xs"
                        />
                        <span className="text-slate-400">/</span>
                        <input
                          type="number"
                          placeholder="Dia"
                          value={vitalsData.bloodPressureDia}
                          onChange={e => setVitalsData({ ...vitalsData, bloodPressureDia: parseInt(e.target.value) || 80 })}
                          className="w-full px-2 py-1.5 rounded-lg bg-white border border-slate-200 text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600">Pulse (bpm)</label>
                      <input
                        type="number"
                        value={vitalsData.pulseRate}
                        onChange={e => setVitalsData({ ...vitalsData, pulseRate: parseInt(e.target.value) || 75 })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600">Weight (kg)</label>
                      <input
                        type="number"
                        step="0.5"
                        value={vitalsData.weight}
                        onChange={e => setVitalsData({ ...vitalsData, weight: parseFloat(e.target.value) || 70 })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-white border border-slate-200 text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold shadow-lg shadow-teal-700/20 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Save to Cloud Database</span>
                </button>
              </div>

            </form>
          )}

        </div>

      </div>
    </div>
  );
};
