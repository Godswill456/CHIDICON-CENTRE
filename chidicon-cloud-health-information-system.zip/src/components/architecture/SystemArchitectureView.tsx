import React, { useState } from 'react';
import { 
  Server, 
  Database, 
  ShieldCheck, 
  Layers, 
  Cpu, 
  Cloud, 
  Workflow, 
  CheckCircle2, 
  FileText, 
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Lock,
  Globe2,
  HardDrive
} from 'lucide-react';

export const SystemArchitectureView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'comparison' | 'er_schema' | 'specifications'>('architecture');

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-700 text-xs font-bold font-mono">
              Research & System Design (Chapter 3)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">Chidicon Medical Centre, Owerri</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Design & Architecture of Cloud-Based HIS
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Full specification, 3-Tier cloud decomposition, data flow diagrams, and relational schemas.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'architecture' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            3-Tier Architecture
          </button>
          <button
            onClick={() => setActiveTab('comparison')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'comparison' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            System Comparison
          </button>
          <button
            onClick={() => setActiveTab('er_schema')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'er_schema' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Database Schema & E-R
          </button>
          <button
            onClick={() => setActiveTab('specifications')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'specifications' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            I/O Specifications
          </button>
        </div>
      </div>

      {/* Tab 1: 3-Tier Cloud Architecture */}
      {activeTab === 'architecture' && (
        <div className="space-y-6">
          
          {/* Visual Architecture Diagram */}
          <div className="bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 text-white rounded-3xl p-6 lg:p-8 shadow-xl border border-teal-800/40 relative overflow-hidden">
            <div className="max-w-3xl">
              <span className="px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-[11px] font-mono font-bold uppercase tracking-wider border border-teal-500/30">
                Figure 3.1: Cloud HIS Topology
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white mt-3">
                Distributed 3-Tier Cloud Architecture
              </h3>
              <p className="text-xs sm:text-sm text-teal-100/80 mt-1 leading-relaxed">
                Seamless synchronization between Owerri hospital workstations (Doctors, Nurses, Pharmacy, Lab, Front Desk) and resilient Cloud Storage nodes.
              </p>
            </div>

            {/* Interactive 3-Tier Blocks */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
              
              {/* Tier 1 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 space-y-3">
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/30 flex items-center justify-center text-teal-300">
                  <Globe2 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-teal-300 uppercase tracking-wider block">TIER 1</span>
                  <h4 className="font-bold text-sm text-white">Presentation Layer</h4>
                </div>
                <p className="text-xs text-teal-100/70 leading-relaxed">
                  Responsive Single-Page Web/Mobile client rendered on hospital workstations, tablets, and smartphones.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-teal-200">
                  • Role-Based Dashboards<br />
                  • Real-time Vitals & Triage<br />
                  • Offline-First Cache Layer
                </div>
              </div>

              {/* Tier 2 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider block">TIER 2</span>
                  <h4 className="font-bold text-sm text-white">Business Logic / Cloud API</h4>
                </div>
                <p className="text-xs text-emerald-100/70 leading-relaxed">
                  Processes authentication, appointment queuing, ICD-10 validation, e-Rx routing, and lab test orchestration.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-emerald-200">
                  • Express.js / Cloud Node Gateway<br />
                  • RBAC Authorization Guard<br />
                  • Real-time Audit Logger
                </div>
              </div>

              {/* Tier 3 */}
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 space-y-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-sky-300 uppercase tracking-wider block">TIER 3</span>
                  <h4 className="font-bold text-sm text-white">Cloud Database & Storage</h4>
                </div>
                <p className="text-xs text-sky-100/70 leading-relaxed">
                  Encrypted, highly available relational and document cloud persistence for immutable medical records.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-sky-200">
                  • Automated Cloud Backups<br />
                  • AES-256 Data Encryption<br />
                  • Zero-Loss Failover
                </div>
              </div>

            </div>
          </div>

          {/* Research Context & Motivation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                3.1 Introduction & Problem Background
              </h4>
              <p className="text-xs text-slate-700 leading-relaxed">
                Healthcare delivery in private hospitals across Owerri, Imo State, has historically suffered from manual paper-card filing systems, misplaced medical records, long outpatient queues, prescription transcription errors, and fragmented patient histories between departments.
              </p>
              <p className="text-xs text-slate-700 leading-relaxed">
                This project establishes an automated, cloud-integrated Health Information System tailored for private healthcare providers (such as Chidicon Medical Centre), ensuring uninterrupted record access, role-based privacy, and high-speed clinical workflows.
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                3.4 Key Cloud Architecture Capabilities
              </h4>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Universal Patient ID (CH-2026-XXXX):</strong> Unique barcode-ready identifier prevents duplicate folders and card mix-ups.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Synchronous Clinical Handshake:</strong> Doctor prescriptions and lab orders immediately populate pharmacy and laboratory terminals.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span><strong>Disaster Recovery:</strong> Cloud replication safeguards patient records against local hardware failure or physical facility damage.</span>
                </li>
              </ul>
            </div>
          </div>

        </div>
      )}

      {/* Tab 2: System Comparison (Existing vs Proposed) */}
      {activeTab === 'comparison' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Table 3.1: Analysis of Existing Manual System vs Proposed Cloud HIS
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Comparative analysis based on clinical operations in Owerri private hospitals (Section 3.2 & 3.3).
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                  <th className="py-3 px-4 w-1/4">Evaluation Parameter</th>
                  <th className="py-3 px-4 w-3/8 text-rose-800 bg-rose-50/70">Existing Manual / Paper-Based System</th>
                  <th className="py-3 px-4 w-3/8 text-teal-800 bg-teal-50/70">Proposed Cloud HIS (Chidicon HIS)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-800">Record Retrieval Speed</td>
                  <td className="py-3 px-4 text-slate-600 bg-rose-50/20">15 – 45 minutes searching physical shelves</td>
                  <td className="py-3 px-4 text-teal-900 font-bold bg-teal-50/20">&lt; 1.5 seconds via instant cloud search</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-800">Data Loss & Damage Risk</td>
                  <td className="py-3 px-4 text-slate-600 bg-rose-50/20">High (paper wear, insect damage, misplacement, fire)</td>
                  <td className="py-3 px-4 text-teal-900 font-bold bg-teal-50/20">Zero loss (Cloud snapshots and encrypted replication)</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-800">Prescription Accuracy</td>
                  <td className="py-3 px-4 text-slate-600 bg-rose-50/20">Prone to illegible handwriting and dosage confusion</td>
                  <td className="py-3 px-4 text-teal-900 font-bold bg-teal-50/20">Standardized electronic prescriptions (e-Rx)</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-800">Inter-Department Flow</td>
                  <td className="py-3 px-4 text-slate-600 bg-rose-50/20">Patient manually ferries paper slips between desks</td>
                  <td className="py-3 px-4 text-teal-900 font-bold bg-teal-50/20">Automated digital queues for Triage, Doctor, Lab & Pharmacy</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-800">Confidentiality & Privacy</td>
                  <td className="py-3 px-4 text-slate-600 bg-rose-50/20">Physical files visible to anyone in records office</td>
                  <td className="py-3 px-4 text-teal-900 font-bold bg-teal-50/20">Strict Role-Based Access Control (RBAC) & Audit trails</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-800">Reporting & Analytics</td>
                  <td className="py-3 px-4 text-slate-600 bg-rose-50/20">Manual tallying on paper ledgers (takes weeks)</td>
                  <td className="py-3 px-4 text-teal-900 font-bold bg-teal-50/20">Real-time morbidity, HMO billing & epidemiology analytics</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Database Schemas & Entity Relations */}
      {activeTab === 'er_schema' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <h3 className="text-base font-bold text-slate-900">
              Section 3.7.3: Database Structure & Entity Data Dictionary
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Relational schemas and data fields implemented in the cloud database.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
              
              {/* Entity: Patient */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-teal-800 flex items-center justify-between">
                  <span>1. Table: PATIENTS</span>
                  <span className="text-[10px] bg-teal-100 px-1.5 py-0.2 rounded">Primary Entity</span>
                </div>
                <ul className="space-y-1 text-slate-600 font-mono text-[11px]">
                  <li><strong>PatientID</strong> (VARCHAR, PK)</li>
                  <li>FullName (VARCHAR)</li>
                  <li>DOB / Age (DATE / INT)</li>
                  <li>Gender (VARCHAR)</li>
                  <li>Phone / Address (VARCHAR)</li>
                  <li>LGA / State (VARCHAR)</li>
                  <li>BloodGroup / Genotype (VARCHAR)</li>
                  <li>HMOProvider (VARCHAR)</li>
                  <li>EmergencyContact (JSON)</li>
                </ul>
              </div>

              {/* Entity: MedicalRecord */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-emerald-800 flex items-center justify-between">
                  <span>2. Table: MEDICAL_RECORDS</span>
                  <span className="text-[10px] bg-emerald-100 px-1.5 py-0.2 rounded">Clinical EMR</span>
                </div>
                <ul className="space-y-1 text-slate-600 font-mono text-[11px]">
                  <li><strong>RecordID</strong> (VARCHAR, PK)</li>
                  <li>PatientID (VARCHAR, FK)</li>
                  <li>DoctorID / DoctorName (VARCHAR)</li>
                  <li>Date (TIMESTAMP)</li>
                  <li>VisitType (VARCHAR)</li>
                  <li>ChiefComplaint (TEXT)</li>
                  <li>Diagnosis / ICDCode (VARCHAR)</li>
                  <li>TreatmentPlan (TEXT)</li>
                  <li>VitalsSnapshot (JSON)</li>
                </ul>
              </div>

              {/* Entity: Prescription */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-rose-800 flex items-center justify-between">
                  <span>3. Table: PRESCRIPTIONS</span>
                  <span className="text-[10px] bg-rose-100 px-1.5 py-0.2 rounded">Pharmacy e-Rx</span>
                </div>
                <ul className="space-y-1 text-slate-600 font-mono text-[11px]">
                  <li><strong>PrescriptionID</strong> (VARCHAR, PK)</li>
                  <li>RecordID (VARCHAR, FK)</li>
                  <li>PatientID (VARCHAR, FK)</li>
                  <li>DrugName (VARCHAR)</li>
                  <li>Dosage / Frequency (VARCHAR)</li>
                  <li>Duration / Route (VARCHAR)</li>
                  <li>Status (pending/dispensed)</li>
                  <li>DispensedBy (VARCHAR)</li>
                </ul>
              </div>

              {/* Entity: LabTests */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-purple-800 flex items-center justify-between">
                  <span>4. Table: LAB_INVESTIGATIONS</span>
                  <span className="text-[10px] bg-purple-100 px-1.5 py-0.2 rounded">Diagnostics</span>
                </div>
                <ul className="space-y-1 text-slate-600 font-mono text-[11px]">
                  <li><strong>LabTestID</strong> (VARCHAR, PK)</li>
                  <li>PatientID (VARCHAR, FK)</li>
                  <li>TestName / Category (VARCHAR)</li>
                  <li>DoctorName (VARCHAR)</li>
                  <li>RequestDate (TIMESTAMP)</li>
                  <li>Status (requested/completed)</li>
                  <li>Results (TEXT)</li>
                  <li>ScientistNotes (TEXT)</li>
                </ul>
              </div>

              {/* Entity: Appointments */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-sky-800 flex items-center justify-between">
                  <span>5. Table: APPOINTMENTS</span>
                  <span className="text-[10px] bg-sky-100 px-1.5 py-0.2 rounded">Queue Desk</span>
                </div>
                <ul className="space-y-1 text-slate-600 font-mono text-[11px]">
                  <li><strong>AppointmentID</strong> (VARCHAR, PK)</li>
                  <li>PatientID (VARCHAR, FK)</li>
                  <li>DoctorID / Name (VARCHAR)</li>
                  <li>Department (VARCHAR)</li>
                  <li>Date / Time (DATETIME)</li>
                  <li>Reason (TEXT)</li>
                  <li>Status (waiting/consult/done)</li>
                </ul>
              </div>

              {/* Entity: Users */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-indigo-800 flex items-center justify-between">
                  <span>6. Table: STAFF_USERS</span>
                  <span className="text-[10px] bg-indigo-100 px-1.5 py-0.2 rounded">RBAC Security</span>
                </div>
                <ul className="space-y-1 text-slate-600 font-mono text-[11px]">
                  <li><strong>UserID</strong> (VARCHAR, PK)</li>
                  <li>Username / Email (VARCHAR, UK)</li>
                  <li>Role (admin/doctor/nurse/etc)</li>
                  <li>Department (VARCHAR)</li>
                  <li>LicenseNumber (VARCHAR)</li>
                  <li>ActiveStatus (BOOLEAN)</li>
                </ul>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* Tab 4: I/O Specifications */}
      {activeTab === 'specifications' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Section 3.7.1 & 3.7.2: Input and Output Specifications
          </h3>
          <p className="text-xs text-slate-500">
            Hardware, browser clients, and data payload specifications according to the research document.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 text-xs">
            <div className="space-y-3">
              <h4 className="font-bold text-teal-800 uppercase tracking-wider text-[11px]">
                Input Forms & Data Capture Specification
              </h4>
              <ul className="space-y-2 text-slate-700">
                <li className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <strong>Patient Bio-Data Capture (Form 01):</strong> Captures name, age, phone, address, emergency next-of-kin, HMO scheme, allergies, and blood indices.
                </li>
                <li className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <strong>Vital Signs Triage (Form 02):</strong> Captures temperature (°C), systolic/diastolic blood pressure (mmHg), pulse rate, respiratory rate, and SpO2.
                </li>
                <li className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <strong>Clinical Encounter & e-Prescription (Form 03):</strong> Records chief complaints, systemic review, ICD-10 diagnosis, and medication dosage regimens.
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-teal-800 uppercase tracking-wider text-[11px]">
                Output Reports & Visual Specification
              </h4>
              <ul className="space-y-2 text-slate-700">
                <li className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <strong>Electronic Patient Hospital Card (Output 01):</strong> Official printable card featuring patient identity, blood group, barcode ID, and emergency contact.
                </li>
                <li className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <strong>Clinical Consultation Summary & Case Sheet (Output 02):</strong> Comprehensive medical history for doctor reviews and legal records.
                </li>
                <li className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <strong>Morbidity & Epidemiology Statistical Reports (Output 03):</strong> Aggregates prevalent diseases (Malaria, Typhoid, Hypertension) for healthcare planning.
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
