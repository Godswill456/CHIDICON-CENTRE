import React, { useState } from 'react';
import { 
  BarChart3, 
  FileSpreadsheet, 
  Download, 
  Printer, 
  TrendingUp, 
  Calendar, 
  Filter, 
  Users, 
  Activity, 
  Pill, 
  TestTube2,
  CheckCircle2
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';

export const HospitalReports: React.FC = () => {
  const { patients, medicalRecords, appointments, labTests, getAllPrescriptions } = useHospital();

  const [dateRange, setDateRange] = useState<'this_month' | 'quarter' | 'year'>('this_month');
  const [reportType, setReportType] = useState<'epidemiology' | 'consultations' | 'pharmacy' | 'demographics'>('epidemiology');

  // Disease frequency computation
  const diseaseFrequency: { [key: string]: number } = {};
  medicalRecords.forEach(r => {
    const diag = r.diagnosis || 'Unspecified';
    diseaseFrequency[diag] = (diseaseFrequency[diag] || 0) + 1;
  });

  // LGA breakdown
  const lgaBreakdown: { [key: string]: number } = {};
  patients.forEach(p => {
    lgaBreakdown[p.lga] = (lgaBreakdown[p.lga] || 0) + 1;
  });

  // HMO Distribution
  const hmoBreakdown: { [key: string]: number } = {};
  patients.forEach(p => {
    const provider = p.hmoProvider.split('/')[0].trim();
    hmoBreakdown[provider] = (hmoBreakdown[provider] || 0) + 1;
  });

  const prescriptions = getAllPrescriptions();

  const handleExportCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "PatientID,FullName,Gender,Age,LGA,HMO,BloodGroup,Genotype,RegisteredDate\n"
      + patients.map(p => `"${p.id}","${p.fullName}","${p.gender}","${p.age}","${p.lga}","${p.hmoProvider}","${p.bloodGroup}","${p.genotype}","${p.registeredAt}"`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Chidicon_Hospital_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-xs font-bold font-mono">
              Module 8 (Sec 3.6.2 #6)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">Executive Analytics & Clinical Audit</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Clinical Health Reports & Operational Analytics
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Epidemiological trends across Owerri municipal clusters, patient demographics, and pharmacy utilization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-teal-700" />
            <span>Export CSV Dataset</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Clinical Audit</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Ribbon */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Registered</div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">{patients.length}</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">100% Digital Cloud EMR</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Clinical Consults</div>
          <div className="text-2xl font-extrabold text-teal-700 mt-1">{medicalRecords.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Recorded by certified doctors</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Lab Investigations</div>
          <div className="text-2xl font-extrabold text-purple-700 mt-1">{labTests.length}</div>
          <div className="text-[11px] text-purple-600 font-semibold mt-1">Pathology & Parasitology</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Prescriptions Filled</div>
          <div className="text-2xl font-extrabold text-rose-700 mt-1">{prescriptions.length}</div>
          <div className="text-[11px] text-rose-600 font-semibold mt-1">Pharmacy Dispensing Active</div>
        </div>
      </div>

      {/* Detailed Report Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Top Diagnoses / Epidemiology in Owerri */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <span>Morbidity & Top Clinical Diagnoses</span>
            </h3>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-600 uppercase">
              Owerri Cluster
            </span>
          </div>

          <div className="space-y-3">
            {Object.entries(diseaseFrequency).map(([disease, count], i) => {
              const pct = Math.round((count / (medicalRecords.length || 1)) * 100);
              return (
                <div key={disease} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between font-semibold">
                    <span className="text-slate-800">{disease}</span>
                    <span className="text-teal-700 font-bold">{count} cases ({pct}%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div 
                      className="h-full rounded-full bg-gradient-to-r from-teal-500 to-emerald-600"
                      style={{ width: `${Math.max(pct, 12)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Geographic Catchment (Imo State LGAs) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-600" />
              <span>Geographical Patient Distribution (LGAs)</span>
            </h3>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
              Imo State
            </span>
          </div>

          <div className="space-y-3">
            {Object.entries(lgaBreakdown).map(([lga, count]) => {
              const pct = Math.round((count / (patients.length || 1)) * 100);
              return (
                <div key={lga} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between font-semibold">
                    <span className="text-slate-800">{lga} Local Govt Area</span>
                    <span className="text-emerald-700 font-bold">{count} patients ({pct}%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div 
                      className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-600"
                      style={{ width: `${Math.max(pct, 10)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Health Insurance & Payment Schemes */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-purple-600" />
              <span>HMO & Payment Scheme Breakdown</span>
            </h3>
          </div>

          <div className="space-y-2.5">
            {Object.entries(hmoBreakdown).map(([hmo, count]) => (
              <div key={hmo} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <span className="font-semibold text-slate-800">{hmo}</span>
                <span className="font-bold text-purple-800 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
                  {count} enrolled
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* System Audit & Performance Info */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-sky-600" />
              <span>Cloud EMR Health & Availability Audit</span>
            </h3>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Database Engine:</span>
              <span className="font-mono font-semibold text-teal-800">Chidicon Cloud Hybrid Storage (v3.2)</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Node Sync Latency:</span>
              <span className="font-semibold text-emerald-600">&lt; 18ms (Cloud Fast-Path)</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Audit Compliance:</span>
              <span className="font-semibold text-slate-800">NDPR & ISO 27799 Compliant</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-500">Active Node Cluster:</span>
              <span className="font-semibold text-slate-800">Owerri Municipal Tier-2 Edge</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
