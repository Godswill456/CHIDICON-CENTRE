import React, { useState } from 'react';
import { 
  CalendarCheck2, 
  Plus, 
  Search, 
  Filter, 
  Clock, 
  User, 
  Stethoscope, 
  CheckCircle2, 
  XCircle, 
  Calendar, 
  AlertCircle,
  Phone,
  ChevronRight
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Appointment, Patient } from '../../types';

interface AppointmentManagerProps {
  onSelectPatient: (patientId: string) => void;
  onOpenConsultationWithPatient: (patientId: string) => void;
  preSelectedPatient?: Patient | null;
  onClearPreSelectedPatient?: () => void;
}

export const AppointmentManager: React.FC<AppointmentManagerProps> = ({
  onSelectPatient,
  onOpenConsultationWithPatient,
  preSelectedPatient,
  onClearPreSelectedPatient,
}) => {
  const { appointments, patients, createAppointment, updateAppointmentStatus } = useHospital();
  const { currentUser, allUsers } = useAuth();

  const [filterDate, setFilterDate] = useState('2026-09-01');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterDepartment, setFilterDepartment] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // New Appointment Modal State
  const [showModal, setShowModal] = useState(Boolean(preSelectedPatient));
  const [formData, setFormData] = useState({
    patientId: preSelectedPatient?.id || (patients[0]?.id || ''),
    doctorId: 'USR-002', // Dr. Amaka Nwachukwu
    department: 'General Outpatient' as Appointment['department'],
    date: '2026-09-01',
    time: '11:00',
    reason: '',
    notes: '',
  });

  const doctors = allUsers.filter(u => u.role === 'doctor' || u.role === 'admin');

  // Filter appointments
  const filteredAppointments = appointments.filter(apt => {
    const matchesDate = !filterDate || apt.date === filterDate;
    const matchesStatus = filterStatus === 'all' || apt.status === filterStatus;
    const matchesDept = filterDepartment === 'all' || apt.department === filterDepartment;
    const matchesSearch = 
      apt.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.reason.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesDate && matchesStatus && matchesDept && matchesSearch;
  });

  const handleCreateAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedPatient = patients.find(p => p.id === formData.patientId);
    const selectedDoctor = allUsers.find(u => u.id === formData.doctorId);

    if (!selectedPatient || !selectedDoctor) return;

    createAppointment({
      patientId: selectedPatient.id,
      patientName: selectedPatient.fullName,
      patientPhone: selectedPatient.phone,
      doctorName: selectedDoctor.name,
      doctorId: selectedDoctor.id,
      department: formData.department,
      date: formData.date,
      time: formData.time,
      reason: formData.reason.trim() || 'General Clinical Review',
      status: 'scheduled',
      notes: formData.notes.trim() || undefined,
    });

    setShowModal(false);
    if (onClearPreSelectedPatient) onClearPreSelectedPatient();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Header & New Appointment Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-sky-50 text-sky-700 text-xs font-bold font-mono">
              Module 3 (Sec 3.6.2)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">{appointments.length} Total Scheduled</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Clinical Appointment & Queue Management
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage outpatient queues, clinic consultation schedules, and doctor assignments.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs flex items-center gap-2 shadow-sm shadow-teal-700/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Book New Appointment</span>
        </button>
      </div>

      {/* Filter and Date Selection Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search patient, doctor, reason..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 text-xs text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-teal-500 outline-none"
          />
        </div>

        {/* Date Filter */}
        <div>
          <input
            type="date"
            value={filterDate}
            onChange={e => setFilterDate(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 text-xs text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-teal-500 outline-none font-medium"
          />
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 text-xs text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-teal-500 outline-none font-medium"
          >
            <option value="all">All Statuses</option>
            <option value="waiting">Waiting (In Clinic Queue)</option>
            <option value="in_consultation">In Consultation</option>
            <option value="scheduled">Scheduled</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        {/* Department Filter */}
        <div>
          <select
            value={filterDepartment}
            onChange={e => setFilterDepartment(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 text-xs text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-teal-500 outline-none font-medium"
          >
            <option value="all">All Departments</option>
            <option value="General Outpatient">General Outpatient (GOPD)</option>
            <option value="Internal Medicine">Internal Medicine</option>
            <option value="Paediatrics">Paediatrics</option>
            <option value="Obstetrics & Gynaecology">Obstetrics & Gynaecology</option>
            <option value="Surgery">Surgery</option>
          </select>
        </div>

      </div>

      {/* Appointments List View */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="divide-y divide-slate-100">
          {filteredAppointments.length > 0 ? (
            filteredAppointments.map(apt => (
              <div 
                key={apt.id} 
                className="p-4 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Left: Time, Patient and Doctor Info */}
                <div className="flex items-start gap-3.5">
                  <div className="w-14 h-14 rounded-2xl bg-teal-50 border border-teal-200 flex flex-col items-center justify-center shrink-0">
                    <span className="text-[10px] font-bold text-teal-700 uppercase">TIME</span>
                    <span className="text-sm font-extrabold text-teal-900">{apt.time}</span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span 
                        onClick={() => onSelectPatient(apt.patientId)}
                        className="text-sm font-bold text-slate-900 hover:text-teal-700 cursor-pointer"
                      >
                        {apt.patientName}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                        {apt.patientId}
                      </span>
                      <span className="text-xs text-slate-400">•</span>
                      <span className="text-xs text-slate-500 font-medium">{apt.patientPhone}</span>
                    </div>

                    <div className="text-xs text-slate-600 flex flex-wrap items-center gap-x-3 gap-y-1">
                      <span>Dept: <strong>{apt.department}</strong></span>
                      <span>Doctor: <strong className="text-teal-700">{apt.doctorName}</strong></span>
                    </div>

                    <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100 italic">
                      "{apt.reason}"
                    </p>
                  </div>
                </div>

                {/* Right: Status and Workflow Buttons */}
                <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                  <span className={`text-[11px] font-bold uppercase px-3 py-1 rounded-full border ${
                    apt.status === 'in_consultation' ? 'bg-teal-50 text-teal-700 border-teal-200 animate-pulse' :
                    apt.status === 'waiting' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                    apt.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                    apt.status === 'cancelled' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                    'bg-slate-100 text-slate-700 border-slate-200'
                  }`}>
                    {apt.status.replace('_', ' ')}
                  </span>

                  {/* Actions according to status */}
                  {apt.status === 'scheduled' && (
                    <button
                      onClick={() => updateAppointmentStatus(apt.id, 'waiting', 'Patient checked in at triage desk')}
                      className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold border border-amber-200 transition-colors"
                    >
                      Check-In (Triage)
                    </button>
                  )}

                  {apt.status === 'waiting' && (
                    <button
                      onClick={() => {
                        updateAppointmentStatus(apt.id, 'in_consultation');
                        onOpenConsultationWithPatient(apt.patientId);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1"
                    >
                      <Stethoscope className="w-3.5 h-3.5" />
                      <span>Start Consult</span>
                    </button>
                  )}

                  {apt.status === 'in_consultation' && (
                    <button
                      onClick={() => onOpenConsultationWithPatient(apt.patientId)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs transition-colors"
                    >
                      Open EMR Desk
                    </button>
                  )}

                  {apt.status !== 'completed' && apt.status !== 'cancelled' && (
                    <button
                      onClick={() => updateAppointmentStatus(apt.id, 'cancelled', 'Cancelled by patient or hospital admin')}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Cancel Appointment"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-slate-500 text-xs">
              <CalendarCheck2 className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p>No appointments match the selected filters.</p>
            </div>
          )}
        </div>
      </div>

      {/* Book Appointment Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <Calendar className="w-4 h-4 text-teal-700" />
                <span>Book Clinical Consultation Appointment</span>
              </div>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600 text-sm">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAppointment} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Patient *</label>
                <select
                  value={formData.patientId}
                  onChange={e => setFormData({ ...formData, patientId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-900 outline-none"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.fullName} ({p.id}) • {p.phone}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Consulting Doctor *</label>
                  <select
                    value={formData.doctorId}
                    onChange={e => setFormData({ ...formData, doctorId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-900 outline-none"
                  >
                    {doctors.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.department.split('&')[0]})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Department *</label>
                  <select
                    value={formData.department}
                    onChange={e => setFormData({ ...formData, department: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-900 outline-none"
                  >
                    <option value="General Outpatient">General Outpatient (GOPD)</option>
                    <option value="Internal Medicine">Internal Medicine</option>
                    <option value="Paediatrics">Paediatrics</option>
                    <option value="Obstetrics & Gynaecology">Obstetrics & Gynaecology</option>
                    <option value="Surgery">Surgery</option>
                    <option value="Cardiology">Cardiology</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Appointment Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.date}
                    onChange={e => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Appointment Time *</label>
                  <input
                    type="time"
                    required
                    value={formData.time}
                    onChange={e => setFormData({ ...formData, time: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Reason for Visit / Clinical Chief Complaint *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Fever, Routine Antenatal, Hypertension Review"
                  value={formData.reason}
                  onChange={e => setFormData({ ...formData, reason: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold shadow-md shadow-teal-700/20 cursor-pointer"
                >
                  Confirm & Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
