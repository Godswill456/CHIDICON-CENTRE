import React from 'react';
import { 
  LayoutDashboard, 
  UserPlus, 
  FolderHeart, 
  CalendarCheck2, 
  Stethoscope, 
  Pill, 
  TestTube2, 
  Users, 
  BarChart3, 
  ShieldCheck, 
  FileCode2, 
  Sparkles,
  ChevronRight,
  Database
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';

interface SidebarProps {
  currentView: string;
  onNavigate?: (view: string) => void;
  onSelectView?: (view: string) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  currentView, 
  onNavigate,
  onSelectView, 
  isOpenMobile = false, 
  onCloseMobile 
}) => {
  const { currentUser, hasPermission } = useAuth();
  const { appointments, medicalRecords } = useHospital();

  const pendingRxCount = medicalRecords.reduce((acc, rec) => 
    acc + rec.prescriptions.filter(p => p.status === 'pending').length, 0
  );

  const waitingAptsCount = appointments.filter(a => a.status === 'waiting').length;

  const menuItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      roles: ['admin', 'doctor', 'nurse', 'receptionist', 'pharmacist', 'lab_scientist'],
      badge: null,
    },
    {
      id: 'registration',
      label: '1. Patient Registration',
      sublabel: 'New Patient Intake & ID',
      icon: UserPlus,
      roles: ['admin', 'receptionist', 'nurse'],
      badge: null,
    },
    {
      id: 'records',
      label: '2. Patient Records & EMR',
      sublabel: 'Directory & History',
      icon: FolderHeart,
      roles: ['admin', 'doctor', 'nurse', 'receptionist', 'pharmacist', 'lab_scientist'],
      badge: null,
    },
    {
      id: 'appointments',
      label: '3. Appointments',
      sublabel: 'Scheduling & Queue',
      icon: CalendarCheck2,
      roles: ['admin', 'doctor', 'receptionist', 'nurse'],
      badge: waitingAptsCount > 0 ? `${waitingAptsCount} waiting` : null,
      badgeColor: 'bg-amber-100 text-amber-700',
    },
    {
      id: 'consultation',
      label: '4. Medical Records / Clinic',
      sublabel: 'Doctor Consult & Rx',
      icon: Stethoscope,
      roles: ['admin', 'doctor'],
      badge: null,
    },
    {
      id: 'pharmacy',
      label: '5. Pharmacy & Prescriptions',
      sublabel: 'Dispense & Stock',
      icon: Pill,
      roles: ['admin', 'pharmacist', 'doctor', 'nurse'],
      badge: pendingRxCount > 0 ? `${pendingRxCount} pending` : null,
      badgeColor: 'bg-rose-100 text-rose-700',
    },
    {
      id: 'laboratory',
      label: '6. Diagnostic Laboratory',
      sublabel: 'Pathology & Tests',
      icon: TestTube2,
      roles: ['admin', 'lab_scientist', 'doctor'],
      badge: null,
    },
    {
      id: 'users',
      label: '7. User Management',
      sublabel: 'Staff & Roles (Admin)',
      icon: Users,
      roles: ['admin'],
      badge: 'Admin',
      badgeColor: 'bg-purple-100 text-purple-700',
    },
    {
      id: 'reports',
      label: '8. Administrative Reports',
      sublabel: 'Analytics & Disease Trends',
      icon: BarChart3,
      roles: ['admin', 'doctor'],
      badge: null,
    },
  ];

  const secondaryItems = [
    {
      id: 'architecture',
      label: 'System Design & ERD',
      sublabel: 'Chapter 3 Diagrams & Specs',
      icon: FileCode2,
      roles: ['admin', 'doctor', 'nurse', 'receptionist', 'pharmacist', 'lab_scientist'],
    },
    {
      id: 'security',
      label: 'Cloud Backup & Audit',
      sublabel: 'Security & Export/Restore',
      icon: Database,
      roles: ['admin'],
    },
  ];

  const handleItemClick = (id: string) => {
    if (onNavigate) {
      onNavigate(id);
    } else if (onSelectView) {
      onSelectView(id);
    }
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`
          fixed lg:static top-16 bottom-0 left-0 z-40
          w-72 bg-white border-r border-slate-200 flex flex-col justify-between
          transform transition-transform duration-200 ease-in-out
          ${isOpenMobile ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Scrollable Navigation List */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          <div className="px-3 pb-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Hospital Modules (Sec 3.7)</span>
            <span className="text-[10px] font-medium text-teal-700 font-mono">v1.0-Cloud</span>
          </div>

          <div className="space-y-1">
            {menuItems.map(item => {
              const hasAccess = item.roles.includes(currentUser.role) || currentUser.role === 'admin';
              const isActive = currentView === item.id || (item.id === 'records' && (currentView === 'patients' || currentView === 'patient-detail'));

              if (!hasAccess && currentUser.role !== 'admin') {
                return null;
              }

              const Icon = item.icon;

              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`
                    w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-all group
                    ${isActive 
                      ? 'bg-teal-700 text-white font-semibold shadow-sm shadow-teal-700/20' 
                      : 'text-slate-700 hover:bg-slate-100/80 hover:text-slate-900'
                    }
                  `}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`p-1.5 rounded-lg ${isActive ? 'bg-teal-800 text-white' : 'bg-slate-100 text-slate-600 group-hover:text-teal-700 group-hover:bg-teal-50'} transition-colors`}>
                      <Icon className="w-4 h-4 shrink-0" />
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-semibold leading-tight truncate">{item.label}</div>
                      {item.sublabel && (
                        <div className={`text-[10px] leading-tight truncate mt-0.5 ${isActive ? 'text-teal-100' : 'text-slate-400'}`}>
                          {item.sublabel}
                        </div>
                      )}
                    </div>
                  </div>

                  {item.badge && (
                    <span className={`ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded-full shrink-0 ${isActive ? 'bg-white text-teal-800' : item.badgeColor || 'bg-slate-100 text-slate-600'}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-4 pb-2 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Technical Specs & Cloud
          </div>

          <div className="space-y-1">
            {secondaryItems.map(item => {
              const hasAccess = item.roles.includes(currentUser.role) || currentUser.role === 'admin';
              const isActive = currentView === item.id;
              if (!hasAccess && currentUser.role !== 'admin') return null;
              const Icon = item.icon;

              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`
                    w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition-all group
                    ${isActive 
                      ? 'bg-slate-900 text-white font-semibold' 
                      : 'text-slate-700 hover:bg-slate-100/80 hover:text-slate-900'
                    }
                  `}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`p-1.5 rounded-lg ${isActive ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 group-hover:text-slate-900'} transition-colors`}>
                      <Icon className="w-4 h-4 shrink-0" />
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-semibold leading-tight truncate">{item.label}</div>
                      <div className={`text-[10px] leading-tight truncate mt-0.5 ${isActive ? 'text-slate-300' : 'text-slate-400'}`}>
                        {item.sublabel}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition-opacity ${isActive ? 'text-white' : 'text-slate-400'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Hospital Facility Footer Info */}
        <div className="p-3 border-t border-slate-200 bg-slate-50/70">
          <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 text-[11px]">Chidicon Medical Centre</span>
              <span className="text-[9px] font-bold px-1.5 py-0.2 bg-teal-50 text-teal-700 border border-teal-200 rounded">
                Owerri
              </span>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              Private Tertiary Healthcare & Specialized Diagnostic Hospital
            </p>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
              <span>Host: Cloud Node OWR-1</span>
              <span className="text-emerald-600 font-bold">256-bit SSL</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
