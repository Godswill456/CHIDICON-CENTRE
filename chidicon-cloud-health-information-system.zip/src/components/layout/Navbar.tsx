import React, { useState } from 'react';
import { 
  Building2, 
  Cloud, 
  Search, 
  ShieldCheck, 
  UserCheck, 
  ChevronDown, 
  RefreshCw, 
  Clock, 
  HardDrive,
  LogOut,
  Bell,
  CheckCircle2,
  Stethoscope,
  Menu,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';
import { UserRole } from '../../types';

interface NavbarProps {
  onOpenQuickSearch?: () => void;
  onOpenRegistration?: () => void;
  onSelectPatient: (patientId: string) => void;
  onNavigate?: (view: string) => void;
  onToggleMobileMenu?: () => void;
  isMobileMenuOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenQuickSearch, 
  onOpenRegistration,
  onSelectPatient, 
  onNavigate,
  onToggleMobileMenu,
  isMobileMenuOpen 
}) => {
  const { currentUser, loginAsRole, allUsers, logout } = useAuth();
  const { patients, isCloudSynced, lastCloudBackup, triggerCloudBackup } = useHospital();
  
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState(false);

  const handleNavigate = (view: string) => {
    if (onNavigate) {
      onNavigate(view);
    }
  };

  const filteredPatients = searchTerm.trim() 
    ? patients.filter(p => 
        p.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.phone.includes(searchTerm)
      ).slice(0, 5)
    : [];

  const handleManualSync = () => {
    setSyncing(true);
    setTimeout(() => {
      triggerCloudBackup();
      setSyncing(false);
      setSyncToast(true);
      setTimeout(() => setSyncToast(false), 3000);
    }, 800);
  };

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'admin': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'doctor': return 'bg-teal-500/10 text-teal-600 border-teal-500/20';
      case 'nurse': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'receptionist': return 'bg-sky-500/10 text-sky-600 border-sky-500/20';
      case 'pharmacist': return 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20';
      case 'lab_scientist': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      default: return 'bg-slate-500/10 text-slate-600 border-slate-500/20';
    }
  };

  const formatRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'admin': return 'Administrator (CMD)';
      case 'doctor': return 'Medical Consultant / Doctor';
      case 'nurse': return 'Staff Nurse / Triage';
      case 'receptionist': return 'Records Officer / Front Desk';
      case 'pharmacist': return 'Clinical Pharmacist';
      case 'lab_scientist': return 'Medical Lab Scientist';
      case 'patient': return 'Patient Portal';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Hospital Brand & Location */}
          <div className="flex items-center gap-3">
            {onToggleMobileMenu && (
              <button
                onClick={onToggleMobileMenu}
                className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 lg:hidden"
                aria-label="Toggle Navigation Menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}

            <div 
              onClick={() => handleNavigate('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-600 to-emerald-700 flex items-center justify-center text-white shadow-md shadow-teal-700/20 group-hover:scale-105 transition-transform">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-base font-bold text-slate-900 tracking-tight leading-none group-hover:text-teal-700 transition-colors">
                    CHIDICON MEDICAL CENTRE
                  </h1>
                  <span className="hidden md:inline-flex text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">
                    CLOUD HIS
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-medium flex items-center gap-1 mt-0.5">
                  <span>Owerri, Imo State, Nigeria</span>
                  <span className="text-slate-300">•</span>
                  <span className="text-emerald-600 font-semibold flex items-center gap-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Online
                  </span>
                </p>
              </div>
            </div>
          </div>

          {/* Quick Search Patient EMR Input */}
          <div className="relative flex-1 max-w-md hidden sm:block">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                placeholder="Search patient name, ID (e.g. CMC-2026-0101), phone..."
                className="w-full pl-9 pr-4 py-1.5 bg-slate-100 hover:bg-slate-100/80 focus:bg-white text-xs text-slate-800 placeholder-slate-400 rounded-lg border border-transparent focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Live Search Dropdown */}
            {searchFocused && searchTerm && (
              <div 
                className="absolute left-0 right-0 top-full mt-1.5 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                onMouseDown={e => e.preventDefault()}
              >
                <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Patient Records Match ({filteredPatients.length})
                </div>
                {filteredPatients.length > 0 ? (
                  filteredPatients.map(p => (
                    <div
                      key={p.id}
                      onClick={() => {
                        onSelectPatient(p.id);
                        setSearchTerm('');
                        setSearchFocused(false);
                      }}
                      className="px-3 py-2 hover:bg-teal-50/60 cursor-pointer flex items-center justify-between border-b border-slate-100 last:border-none group"
                    >
                      <div>
                        <div className="text-xs font-semibold text-slate-900 group-hover:text-teal-700 flex items-center gap-2">
                          <span>{p.fullName}</span>
                          <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded">
                            {p.id}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span>{p.gender}, {p.age} yrs</span>
                          <span>•</span>
                          <span>{p.lga}</span>
                          <span>•</span>
                          <span className="text-teal-600">{p.phone}</span>
                        </div>
                      </div>
                      <div className="text-[11px] font-semibold text-teal-600 group-hover:underline">
                        View EMR →
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="px-3 py-3 text-center text-xs text-slate-500">
                    No matching patient record found for "{searchTerm}"
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            
            {/* Cloud Status Indicator & Manual Sync */}
            <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-100/80 border border-slate-200/80 text-xs">
              <button
                onClick={handleManualSync}
                disabled={syncing}
                title="Synchronize local changes with Cloud Database"
                className="flex items-center gap-1.5 text-slate-600 hover:text-teal-700 transition-colors cursor-pointer"
              >
                <Cloud className={`w-3.5 h-3.5 ${isCloudSynced ? 'text-teal-600' : 'text-amber-500'}`} />
                <span className="font-medium text-[11px]">Cloud Sync</span>
                <RefreshCw className={`w-3 h-3 text-slate-400 ${syncing ? 'animate-spin text-teal-600' : ''}`} />
              </button>
            </div>

            {/* System Architecture Quick Button */}
            <button
              onClick={() => handleNavigate('architecture')}
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200/80 text-xs font-semibold transition-colors"
              title="View Chapter 3 Interactive System Architecture & Diagrams"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Chapter 3 Specs</span>
            </button>

            {/* Role Switcher & Active User Dropdown */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-2 p-1.5 pl-2 rounded-xl bg-slate-100/70 hover:bg-slate-100 border border-slate-200 transition-all text-left"
              >
                <div className="w-8 h-8 rounded-lg bg-teal-700 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                  {currentUser.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-bold text-slate-900 leading-none">
                    {currentUser.name}
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded border ${getRoleBadgeColor(currentUser.role)}`}>
                      {currentUser.role.toUpperCase()}
                    </span>
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
              </button>

              {/* Role Switcher Popup Menu */}
              {roleDropdownOpen && (
                <div 
                  className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setRoleDropdownOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-slate-100">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Current Active User
                    </div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5">
                      {currentUser.name}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {currentUser.department}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>Last Login: {currentUser.lastLogin || 'Today'}</span>
                    </div>
                  </div>

                  <div className="px-4 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Switch Test Persona / Role
                  </div>

                  <div className="space-y-0.5 px-2 max-h-60 overflow-y-auto">
                    {allUsers.filter(u => u.active).map(u => (
                      <button
                        key={u.id}
                        onClick={() => {
                          loginAsRole(u.role);
                          setRoleDropdownOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                          currentUser.id === u.id 
                            ? 'bg-teal-50 text-teal-800 font-bold' 
                            : 'hover:bg-slate-100 text-slate-700'
                        }`}
                      >
                        <div className="truncate pr-2">
                          <div className="truncate font-medium">{u.name}</div>
                          <div className="text-[10px] text-slate-500">{u.department.split('&')[0]}</div>
                        </div>
                        <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded border ${getRoleBadgeColor(u.role)}`}>
                          {u.role}
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="mt-2 pt-2 px-3 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => {
                        handleNavigate('users');
                        setRoleDropdownOpen(false);
                      }}
                      className="text-xs text-teal-700 hover:text-teal-900 font-semibold"
                    >
                      Manage All Users
                    </button>
                    <button
                      onClick={() => {
                        logout();
                        setRoleDropdownOpen(false);
                      }}
                      className="text-xs text-rose-600 hover:text-rose-800 flex items-center gap-1"
                    >
                      <LogOut className="w-3 h-3" />
                      <span>Switch</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* Sync Toast Notification */}
      {syncToast && (
        <div className="fixed bottom-4 right-4 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs z-50 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Cloud database snapshot synchronized with Owerri Node cluster.</span>
        </div>
      )}
    </header>
  );
};
