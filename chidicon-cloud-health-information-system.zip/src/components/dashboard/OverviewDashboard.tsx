import React from 'react';
import { 
  Users, 
  Calendar, 
  Stethoscope, 
  Pill, 
  TestTube2, 
  Clock, 
  ArrowUpRight, 
  UserPlus, 
  PlusCircle, 
  TrendingUp, 
  CheckCircle2, 
  AlertCircle,
  Activity,
  HeartPulse,
  ShieldCheck,
  Building2,
  CalendarCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';

interface OverviewDashboardProps {
  onNavigate: (view: string) => void;
  onSelectPatient: (patientId: string) => void;
  onOpenNewRegistration: () => void;
  onOpenNewAppointment: () => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  onNavigate,
  onSelectPatient,
  onOpenNewRegistration,
  onOpenNewAppointment,
}) => {
  const { currentUser } = useAuth();
  const { patients, appointments, medicalRecords, labTests, getHospitalStats, updateAppointmentStatus } = useHospital();

  const stats = getHospitalStats();
  const todayApts = appointments.filter(a => a.date === '2026-09-01' || a.date.includes('2026-09-01'));
  const waitingPatients = appointments.filter(a => a.status === 'waiting');
  const recentRecords = medicalRecords.slice(0, 4);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Welcome & Facility Header Banner */}
      <div className="bg-gradient-to-r from-teal-800 via-teal-900 to-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute right-40 bottom-0 translate-y-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 border border-teal-400/30 text-teal-200 text-xs font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                Chidicon Cloud HIS v1.0 • Owerri Node
              </span>
              <span className="text-teal-200/60 text-xs">•</span>
              <span className="text-teal-100 text-xs font-medium">Tuesday, 1 September 2026</span>
            </div>
            
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Welcome back, {currentUser.name}
            </h2>
            
            <p className="text-teal-100/90 text-sm max-w-2xl font-normal leading-relaxed">
              Logged in as <strong className="text-white capitalize">{currentUser.role.replace('_', ' ')}</strong> in <span className="underline decoration-teal-400/50">{currentUser.department}</span>. Real-time clinical records and cloud database are synchronized.
            </p>
          </div>

          {/* Quick Action Button Group */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {(currentUser.role === 'admin' || currentUser.role === 'receptionist' || currentUser.role === 'nurse') && (
              <button
                onClick={onOpenNewRegistration}
                className="px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-teal-500/20 transition-all hover:scale-102 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>Register Patient</span>
              </button>
            )}

            {(currentUser.role === 'admin' || currentUser.role === 'doctor' || currentUser.role === 'receptionist') && (
              <button
                onClick={onOpenNewAppointment}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <CalendarCheck className="w-4 h-4 text-teal-300" />
                <span>Book Appointment</span>
              </button>
            )}

            {(currentUser.role === 'admin' || currentUser.role === 'doctor') && (
              <button
                onClick={() => onNavigate('consultation')}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-emerald-900/40 transition-all cursor-pointer"
              >
                <Stethoscope className="w-4 h-4" />
                <span>Doctor Consultation</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* KPI Stats Metrics Grid (Section 3.7.2) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Registered Patients */}
        <div 
          onClick={() => onNavigate('records')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Patients</span>
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight">{stats.totalPatients}</span>
            <span className="text-xs font-semibold text-emerald-600 flex items-center gap-0.5">
              <TrendingUp className="w-3.5 h-3.5" /> +15 this month
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Full electronic records in cloud database</p>
        </div>

        {/* Today's Appointments */}
        <div 
          onClick={() => onNavigate('appointments')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Today's Clinic</span>
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight">{todayApts.length}</span>
            <span className="text-xs font-bold text-amber-600 px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200">
              {waitingPatients.length} Waiting
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">GOPD & Specialty clinics scheduled</p>
        </div>

        {/* Consultations Recorded */}
        <div 
          onClick={() => onNavigate('consultation')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Consultations</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Stethoscope className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight">{medicalRecords.length}</span>
            <span className="text-xs font-semibold text-teal-600 flex items-center gap-0.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> 100% EMR Saved
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Clinical notes, vitals & treatment plans</p>
        </div>

        {/* Pharmacy & Prescriptions */}
        <div 
          onClick={() => onNavigate('pharmacy')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Pharmacy Orders</span>
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Pill className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight">{stats.pendingPrescriptions}</span>
            <span className="text-xs font-bold text-rose-600 px-2 py-0.5 rounded-full bg-rose-50 border border-rose-200">
              Pending Dispense
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Real-time electronic e-prescriptions</p>
        </div>

      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Today's Clinical Queue & In-Consultation Patients */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Active Clinic Queue Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700">
                  <Activity className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Today's Patient Queue & Triage</h3>
                  <p className="text-[11px] text-slate-500">Live patient appointments and triage flow</p>
                </div>
              </div>
              <button 
                onClick={() => onNavigate('appointments')}
                className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer"
              >
                <span>View Full Schedule</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {todayApts.length > 0 ? (
                todayApts.map(apt => (
                  <div 
                    key={apt.id}
                    className="p-4 hover:bg-slate-50/80 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex flex-col items-center justify-center shrink-0 border border-slate-200">
                        <span className="text-[10px] font-bold text-slate-500 uppercase">TIME</span>
                        <span className="text-xs font-extrabold text-slate-900">{apt.time}</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span 
                            onClick={() => onSelectPatient(apt.patientId)}
                            className="text-sm font-bold text-slate-900 hover:text-teal-700 cursor-pointer"
                          >
                            {apt.patientName}
                          </span>
                          <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded">
                            {apt.patientId}
                          </span>
                        </div>
                        <div className="text-xs text-slate-600 mt-0.5">
                          <span className="font-medium text-slate-700">{apt.department}</span> • Doctor: <span className="font-medium text-teal-700">{apt.doctorName}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 italic mt-0.5">
                          "{apt.reason}"
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-full border ${
                        apt.status === 'in_consultation' ? 'bg-teal-50 text-teal-700 border-teal-200 animate-pulse' :
                        apt.status === 'waiting' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                        apt.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                        'bg-slate-100 text-slate-600 border-slate-200'
                      }`}>
                        {apt.status.replace('_', ' ')}
                      </span>

                      {apt.status === 'waiting' && (
                        <button
                          onClick={() => updateAppointmentStatus(apt.id, 'in_consultation')}
                          className="px-2.5 py-1 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold shadow-xs cursor-pointer"
                        >
                          Call In
                        </button>
                      )}

                      {apt.status === 'in_consultation' && (
                        <button
                          onClick={() => onNavigate('consultation')}
                          className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs cursor-pointer"
                        >
                          Open Consult
                        </button>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-slate-500 text-xs">
                  No appointments scheduled for today.
                </div>
              )}
            </div>
          </div>

          {/* Recent Electronic Medical Records (EMR Consultations) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
                  <Stethoscope className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Recent Medical Consultations & Diagnoses</h3>
                  <p className="text-[11px] text-slate-500">Latest doctor notes and treatment plans</p>
                </div>
              </div>
              <button 
                onClick={() => onNavigate('records')}
                className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer"
              >
                <span>All Records</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {recentRecords.map(rec => {
                const patient = patients.find(p => p.id === rec.patientId);
                return (
                  <div key={rec.id} className="p-4 hover:bg-slate-50/80 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span 
                          onClick={() => onSelectPatient(rec.patientId)}
                          className="text-xs font-bold text-slate-900 hover:text-teal-700 cursor-pointer"
                        >
                          {patient?.fullName || rec.patientId}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">
                          {rec.patientId}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-medium">
                        {rec.date}
                      </span>
                    </div>

                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold">
                        {rec.diagnosis}
                      </span>
                      {rec.icdCode && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                          ICD: {rec.icdCode}
                        </span>
                      )}
                      <span className="text-[11px] text-slate-500">
                        by {rec.doctorName}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mt-2 line-clamp-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <strong>Plan:</strong> {rec.treatmentPlan}
                    </p>

                    {rec.prescriptions.length > 0 && (
                      <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-500">
                        <Pill className="w-3 h-3 text-rose-500" />
                        <span>Prescriptions ({rec.prescriptions.length}):</span>
                        <span className="text-slate-700 font-medium">
                          {rec.prescriptions.map(p => p.drugName.split('(')[0]).join(', ')}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column: Hospital Disease Frequency & Quick Widgets */}
        <div className="space-y-6">
          
          {/* Top Diagnoses in Owerri (Epidemiology Breakdown) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-teal-600" />
                <h3 className="text-sm font-bold text-slate-900">Top Diagnoses in Owerri</h3>
              </div>
              <span className="text-[10px] font-bold px-1.5 py-0.5 bg-teal-50 text-teal-700 rounded">
                Hospital Census
              </span>
            </div>

            <div className="mt-4 space-y-3.5">
              {stats.topDiagnoses.map((diag, index) => (
                <div key={diag.diagnosis} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">{diag.diagnosis}</span>
                    <span className="font-bold text-teal-700">{diag.count} cases ({diag.percentage}%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        index === 0 ? 'bg-teal-600' :
                        index === 1 ? 'bg-emerald-500' :
                        index === 2 ? 'bg-sky-500' :
                        index === 3 ? 'bg-amber-500' : 'bg-purple-500'
                      }`}
                      style={{ width: `${Math.min(diag.percentage * 2.5, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Tropical & Non-communicable disease tracking</span>
              <button 
                onClick={() => onNavigate('reports')} 
                className="text-teal-700 font-semibold hover:underline"
              >
                Full Analytics →
              </button>
            </div>
          </div>

          {/* Quick Laboratory Status Widget */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <TestTube2 className="w-4 h-4 text-purple-600" />
                <h3 className="text-sm font-bold text-slate-900">Diagnostic Laboratory</h3>
              </div>
              <span className="text-xs font-bold text-purple-700">
                {labTests.length} Total
              </span>
            </div>

            <div className="mt-3 divide-y divide-slate-100">
              {labTests.slice(0, 3).map(test => (
                <div key={test.id} className="py-2.5 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{test.testName}</span>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      test.status === 'completed' ? 'bg-emerald-50 text-emerald-700' :
                      test.status === 'in_progress' ? 'bg-amber-50 text-amber-700' :
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {test.status.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 flex items-center justify-between">
                    <span>Patient: {test.patientId}</span>
                    <span className="text-purple-600 font-medium">{test.priority}</span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('laboratory')}
              className="mt-4 w-full py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition-colors"
            >
              Open Lab Workstation
            </button>
          </div>

          {/* Chapter 3 Research Reference Note */}
          <div className="bg-slate-900 rounded-2xl p-4 text-white shadow-md">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-teal-300">
                Research Project Alignment
              </h4>
            </div>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Designed according to Chapter 3 specifications: Waterfall model methodology, role-based security, modular data flows, and centralized cloud EMR for Chidicon Medical Centre, Owerri.
            </p>
            <button
              onClick={() => onNavigate('architecture')}
              className="mt-3 text-xs font-bold text-teal-400 hover:text-teal-300 flex items-center gap-1"
            >
              <span>Explore Chapter 3 System Architecture</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
