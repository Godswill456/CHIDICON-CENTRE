import React, { useState } from 'react';
import { 
  TestTube2, 
  Search, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Upload, 
  FileText, 
  Plus,
  User,
  FlaskConical
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { LabTest } from '../../types';

export const LaboratoryWorkstation: React.FC = () => {
  const { labTests, updateLabTestResult, patients } = useHospital();
  const { currentUser } = useAuth();

  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Result Entry Modal State
  const [activeTestForResults, setActiveTestForResults] = useState<LabTest | null>(null);
  const [resultsText, setResultsText] = useState('');
  const [scientistNotes, setScientistNotes] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const filteredTests = labTests.filter(t => {
    const matchesCategory = filterCategory === 'all' || t.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || t.status === filterStatus;
    const matchesSearch = 
      t.testName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.doctorName.toLowerCase().includes(searchTerm.toLowerCase());

    return matchesCategory && matchesStatus && matchesSearch;
  });

  const handleOpenResultsModal = (test: LabTest) => {
    setActiveTestForResults(test);
    setResultsText(test.results || '');
    setScientistNotes(test.scientistNotes || '');
  };

  const handleSaveResults = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTestForResults) return;

    updateLabTestResult(activeTestForResults.id, resultsText.trim(), scientistNotes.trim() || undefined);
    setActiveTestForResults(null);
    setToastMessage(`Diagnostic test results uploaded for ${activeTestForResults.testName}`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Module Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-purple-50 text-purple-700 text-xs font-bold font-mono">
              Module 6 (Diagnostics)
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 font-medium">Chidicon Diagnostic Laboratory</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">
            Medical Diagnostic Laboratory Workstation
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Process doctor specimen requests, record analytical findings, and validate clinical lab reports.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-xl bg-purple-50 text-purple-800 font-bold border border-purple-200">
            {labTests.length} Total Investigations
          </span>
        </div>
      </div>

      {/* Success Toast */}
      {toastMessage && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 shadow-sm animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search test name, patient ID, doctor..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 text-xs text-slate-900 rounded-xl border border-slate-200 focus:bg-white focus:border-purple-500 outline-none"
          />
        </div>

        <div>
          <select
            value={filterCategory}
            onChange={e => setFilterCategory(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 text-xs text-slate-700 font-medium rounded-xl border border-slate-200 outline-none"
          >
            <option value="all">All Pathology Categories</option>
            <option value="Parasitology">Parasitology (Malaria, Stool)</option>
            <option value="Hematology">Hematology (FBC, Genotype)</option>
            <option value="Chemical Pathology">Chemical Pathology (E/U/Cr, FBS)</option>
            <option value="Microbiology">Microbiology (Culture & Sensitivity)</option>
          </select>
        </div>

        <div>
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 text-xs text-slate-700 font-medium rounded-xl border border-slate-200 outline-none"
          >
            <option value="all">All Lab Statuses</option>
            <option value="requested">Requested / Sample Pending</option>
            <option value="in_progress">In Analysis</option>
            <option value="completed">Completed & Validated</option>
          </select>
        </div>
      </div>

      {/* Investigations Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="divide-y divide-slate-100">
          {filteredTests.length > 0 ? (
            filteredTests.map(test => {
              const patient = patients.find(p => p.id === test.patientId);
              return (
                <div key={test.id} className="p-4 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{test.testName}</span>
                      <span className="px-2 py-0.5 rounded bg-purple-50 text-purple-700 text-[10px] font-bold border border-purple-200">
                        {test.category}
                      </span>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        test.priority === 'Urgent' || test.priority === 'Stat' ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {test.priority}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 flex flex-wrap items-center gap-3">
                      <span>Patient: <strong>{patient?.fullName || test.patientId}</strong> ({test.patientId})</span>
                      <span>•</span>
                      <span>Doctor: <strong>{test.doctorName}</strong></span>
                      <span>•</span>
                      <span className="text-slate-400">Req: {test.requestDate}</span>
                    </div>

                    {test.results && (
                      <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs mt-1">
                        <strong className="text-slate-900 block mb-0.5">Laboratory Findings:</strong>
                        <p className="text-slate-700 font-mono text-[11px]">{test.results}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                    <span className={`text-[10px] font-bold uppercase px-3 py-1 rounded-full ${
                      test.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      test.status === 'in_progress' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                      'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {test.status.replace('_', ' ')}
                    </span>

                    <button
                      onClick={() => handleOpenResultsModal(test)}
                      className="px-3.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{test.status === 'completed' ? 'Update Findings' : 'Enter Results'}</span>
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs">
              <FlaskConical className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p>No laboratory requests matching criteria.</p>
            </div>
          )}
        </div>
      </div>

      {/* Enter Lab Results Modal */}
      {activeTestForResults && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Enter Clinical Lab Results</h3>
                <p className="text-xs text-purple-700 font-semibold">{activeTestForResults.testName}</p>
              </div>
              <button onClick={() => setActiveTestForResults(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveResults} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Diagnostic Values & Findings <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="e.g. Plasmodium falciparum trophozoites seen (++). Density: ~3,500/μL. Or Hb: 12.5 g/dL, PCV: 38%..."
                  value={resultsText}
                  onChange={e => setResultsText(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-purple-500 text-xs font-mono text-slate-900 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Medical Laboratory Scientist Comments / Interpretation
                </label>
                <input
                  type="text"
                  placeholder="e.g. Findings compatible with acute malaria. Repeat thick film recommended in 48 hrs."
                  value={scientistNotes}
                  onChange={e => setScientistNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTestForResults(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold shadow-md shadow-purple-700/20 cursor-pointer"
                >
                  Validate & Upload to Patient EMR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
