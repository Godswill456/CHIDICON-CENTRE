import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { INITIAL_USERS } from '../data/initialData';

interface AuthContextType {
  currentUser: User;
  allUsers: User[];
  loginAsRole: (role: UserRole) => void;
  loginAsUser: (userId: string) => void;
  customLogin: (username: string, role: UserRole, department: string) => boolean;
  logout: () => void;
  hasPermission: (allowedRoles: UserRole[]) => boolean;
  addUser: (user: Omit<User, 'id' | 'createdAt'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  toggleUserStatus: (id: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('chidicon_his_users');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved users', e);
      }
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const savedUser = localStorage.getItem('chidicon_current_user');
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        const match = users.find(u => u.id === parsed.id);
        if (match && match.active) return match;
      } catch (e) {
        console.error('Failed to parse current user', e);
      }
    }
    return users[0]; // Dr. Charles Okoro (Admin)
  });

  useEffect(() => {
    localStorage.setItem('chidicon_his_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('chidicon_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  const loginAsRole = (role: UserRole) => {
    const targetUser = users.find(u => u.role === role && u.active);
    if (targetUser) {
      const updated = {
        ...targetUser,
        lastLogin: new Date().toLocaleString('en-US', {
          timeZone: 'Africa/Lagos',
          dateStyle: 'short',
          timeStyle: 'medium',
        }) + ' WAT',
      };
      setCurrentUser(updated);
    }
  };

  const loginAsUser = (userId: string) => {
    const target = users.find(u => u.id === userId);
    if (target && target.active) {
      setCurrentUser(target);
    }
  };

  const customLogin = (username: string, role: UserRole, department: string): boolean => {
    const existing = users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (existing) {
      if (!existing.active) return false;
      setCurrentUser(existing);
      return true;
    } else {
      const newUser: User = {
        id: `USR-${String(users.length + 1).padStart(3, '0')}`,
        name: username.split('.').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' '),
        username,
        email: `${username.toLowerCase()}@chidicon.org`,
        role,
        department: department || 'Clinical Services',
        phone: '+234 800 000 0000',
        active: true,
        createdAt: new Date().toISOString().split('T')[0],
        lastLogin: 'Just now',
      };
      setUsers(prev => [...prev, newUser]);
      setCurrentUser(newUser);
      return true;
    }
  };

  const logout = () => {
    // Reset to demo prompt or switch to reception
    loginAsRole('receptionist');
  };

  const hasPermission = (allowedRoles: UserRole[]): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'admin') return true; // Admins have oversight across all modules
    return allowedRoles.includes(currentUser.role);
  };

  const addUser = (newUser: Omit<User, 'id' | 'createdAt'>) => {
    const user: User = {
      ...newUser,
      id: `USR-${String(users.length + 1).padStart(3, '0')}`,
      createdAt: new Date().toISOString().split('T')[0],
      lastLogin: 'Never',
    };
    setUsers(prev => [user, ...prev]);
  };

  const updateUser = (id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
    if (currentUser.id === id) {
      setCurrentUser(prev => ({ ...prev, ...updates }));
    }
  };

  const toggleUserStatus = (id: string) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, active: !u.active } : u));
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers: users,
        loginAsRole,
        loginAsUser,
        customLogin,
        logout,
        hasPermission,
        addUser,
        updateUser,
        toggleUserStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
