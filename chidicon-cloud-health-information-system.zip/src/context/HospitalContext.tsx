import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Patient, 
  Appointment, 
  MedicalRecord, 
  PrescriptionItem, 
  LabTest, 
  AuditLog, 
  VitalSigns,
  HospitalStats,
  UserRole
} from '../types';
import { 
  INITIAL_PATIENTS, 
  INITIAL_APPOINTMENTS, 
  INITIAL_MEDICAL_RECORDS, 
  INITIAL_LAB_TESTS, 
  INITIAL_AUDIT_LOGS 
} from '../data/initialData';
import { useAuth } from './AuthContext';

interface HospitalContextType {
  patients: Patient[];
  appointments: Appointment[];
  medicalRecords: MedicalRecord[];
  labTests: LabTest[];
  auditLogs: AuditLog[];
  isCloudSynced: boolean;
  lastCloudBackup: string;
  
  // Patient Actions
  registerPatient: (patientData: Omit<Patient, 'id' | 'registeredAt' | 'registeredBy' | 'vitalsHistory'>, initialVitals?: VitalSigns) => Patient;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  addPatientVitals: (patientId: string, vitals: VitalSigns) => void;
  getPatientById: (id: string) => Patient | undefined;
  
  // Appointment Actions
  createAppointment: (apt: Omit<Appointment, 'id' | 'createdAt'>) => Appointment;
  updateAppointmentStatus: (id: string, status: Appointment['status'], notes?: string) => void;
  
  // Medical Records & Consultation Actions
  createMedicalRecord: (record: Omit<MedicalRecord, 'id' | 'date' | 'status'>) => MedicalRecord;
  updateMedicalRecord: (id: string, updates: Partial<MedicalRecord>) => void;
  
  // Pharmacy & Prescription Actions
  dispensePrescription: (recordId: string, prescriptionId: string) => void;
  getAllPrescriptions: () => { prescription: PrescriptionItem; record: MedicalRecord; patient?: Patient }[];
  
  // Laboratory Actions
  requestLabTest: (test: Omit<LabTest, 'id' | 'requestDate' | 'status'>) => LabTest;
  updateLabTestResult: (id: string, results: string, scientistNotes?: string) => void;
  
  // Security & Cloud Backup
  logAuditEvent: (action: string, module: string, details: string) => void;
  triggerCloudBackup: () => void;
  exportDatabaseJson: () => string;
  importDatabaseJson: (jsonData: string) => boolean;
  resetToDefaultData: () => void;
  
  // Stats
  getHospitalStats: () => HospitalStats;
}

const HospitalContext = createContext<HospitalContextType | undefined>(undefined);

export const HospitalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  const [patients, setPatients] = useState<Patient[]>(() => {
    const saved = localStorage.getItem('chidicon_patients');
    return saved ? JSON.parse(saved) : INITIAL_PATIENTS;
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const saved = localStorage.getItem('chidicon_appointments');
    return saved ? JSON.parse(saved) : INITIAL_APPOINTMENTS;
  });

  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>(() => {
    const saved = localStorage.getItem('chidicon_medical_records');
    return saved ? JSON.parse(saved) : INITIAL_MEDICAL_RECORDS;
  });

  const [labTests, setLabTests] = useState<LabTest[]>(() => {
    const saved = localStorage.getItem('chidicon_lab_tests');
    return saved ? JSON.parse(saved) : INITIAL_LAB_TESTS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem('chidicon_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [isCloudSynced, setIsCloudSynced] = useState<boolean>(true);
  const [lastCloudBackup, setLastCloudBackup] = useState<string>('2026-09-01 16:00 WAT');

  // LocalStorage Persistence
  useEffect(() => {
    localStorage.setItem('chidicon_patients', JSON.stringify(patients));
    setIsCloudSynced(true);
  }, [patients]);

  useEffect(() => {
    localStorage.setItem('chidicon_appointments', JSON.stringify(appointments));
    setIsCloudSynced(true);
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem('chidicon_medical_records', JSON.stringify(medicalRecords));
    setIsCloudSynced(true);
  }, [medicalRecords]);

  useEffect(() => {
    localStorage.setItem('chidicon_lab_tests', JSON.stringify(labTests));
    setIsCloudSynced(true);
  }, [labTests]);

  useEffect(() => {
    localStorage.setItem('chidicon_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  const logAuditEvent = (action: string, module: string, details: string) => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toLocaleString('en-US', {
        timeZone: 'Africa/Lagos',
        dateStyle: 'short',
        timeStyle: 'medium',
      }) + ' WAT',
      userId: currentUser?.id || 'SYSTEM',
      userName: currentUser?.name || 'System Auto-Agent',
      userRole: currentUser?.role || ('admin' as UserRole),
      action,
      module,
      details,
      ipAddress: '192.168.1.' + Math.floor(Math.random() * 50 + 100) + ' (Cloud Node)',
    };
    setAuditLogs(prev => [newLog, ...prev.slice(0, 99)]);
  };

  const registerPatient = (
    patientData: Omit<Patient, 'id' | 'registeredAt' | 'registeredBy' | 'vitalsHistory'>,
    initialVitals?: VitalSigns
  ): Patient => {
    const newCount = patients.length + 101;
    const newId = `CMC-2026-${String(newCount).padStart(4, '0')}`;
    const nowStr = new Date().toISOString().split('T')[0];

    const newPatient: Patient = {
      ...patientData,
      id: newId,
      registeredAt: nowStr,
      registeredBy: currentUser?.name || 'Reception Desk',
      vitalsHistory: initialVitals ? [initialVitals] : [],
    };

    setPatients(prev => [newPatient, ...prev]);
    logAuditEvent(
      'Patient Registration',
      'Patient Registration Module',
      `Registered new patient ${newPatient.fullName} (${newPatient.id}) with LGA ${newPatient.lga}`
    );
    return newPatient;
  };

  const updatePatient = (id: string, updates: Partial<Patient>) => {
    setPatients(prev =>
      prev.map(p => {
        if (p.id === id) {
          const updated = { ...p, ...updates };
          logAuditEvent(
            'Patient Record Update',
            'Patient Records Module',
            `Updated demographic & clinical profile for ${p.fullName} (${id})`
          );
          return updated;
        }
        return p;
      })
    );
  };

  const addPatientVitals = (patientId: string, vitals: VitalSigns) => {
    setPatients(prev =>
      prev.map(p => {
        if (p.id === patientId) {
          const updated = {
            ...p,
            vitalsHistory: [vitals, ...p.vitalsHistory],
          };
          logAuditEvent(
            'Vital Signs Recorded',
            'Triage & Inpatient Module',
            `Recorded BP ${vitals.bloodPressureSys}/${vitals.bloodPressureDia} mmHg & Temp ${vitals.temperature}°C for ${p.fullName}`
          );
          return updated;
        }
        return p;
      })
    );
  };

  const getPatientById = (id: string): Patient | undefined => {
    return patients.find(p => p.id.toLowerCase() === id.toLowerCase());
  };

  const createAppointment = (apt: Omit<Appointment, 'id' | 'createdAt'>): Appointment => {
    const newId = `APT-2026-${String(appointments.length + 1).padStart(3, '0')}`;
    const newApt: Appointment = {
      ...apt,
      id: newId,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setAppointments(prev => [newApt, ...prev]);
    logAuditEvent(
      'Appointment Scheduled',
      'Appointment Module',
      `Booked appointment ${newId} for ${newApt.patientName} with ${newApt.doctorName} on ${newApt.date} at ${newApt.time}`
    );
    return newApt;
  };

  const updateAppointmentStatus = (id: string, status: Appointment['status'], notes?: string) => {
    setAppointments(prev =>
      prev.map(a => {
        if (a.id === id) {
          const updated = { ...a, status, notes: notes || a.notes };
          logAuditEvent(
            'Appointment Status Update',
            'Appointment Module',
            `Changed status of appointment ${id} to [${status.toUpperCase()}] for ${a.patientName}`
          );
          return updated;
        }
        return a;
      })
    );
  };

  const createMedicalRecord = (record: Omit<MedicalRecord, 'id' | 'date' | 'status'>): MedicalRecord => {
    const newId = `MED-2026-${String(medicalRecords.length + 1).padStart(3, '0')}`;
    const dateStr = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos',
      dateStyle: 'short',
      timeStyle: 'medium',
    }) + ' WAT';

    const newRecord: MedicalRecord = {
      ...record,
      id: newId,
      date: dateStr,
      status: 'completed',
    };

    setMedicalRecords(prev => [newRecord, ...prev]);

    // Also update patient vitals history if record vitals exist
    if (record.vitals) {
      addPatientVitals(record.patientId, record.vitals);
    }

    logAuditEvent(
      'Consultation & EMR Creation',
      'Medical Records Module',
      `Doctor ${record.doctorName} recorded diagnosis "${record.diagnosis}" and treatment for ${record.patientId}`
    );

    return newRecord;
  };

  const updateMedicalRecord = (id: string, updates: Partial<MedicalRecord>) => {
    setMedicalRecords(prev =>
      prev.map(r => (r.id === id ? { ...r, ...updates } : r))
    );
  };

  const dispensePrescription = (recordId: string, prescriptionId: string) => {
    const nowStr = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos',
      dateStyle: 'short',
      timeStyle: 'medium',
    }) + ' WAT';

    setMedicalRecords(prev =>
      prev.map(rec => {
        if (rec.id === recordId) {
          const updatedPrescriptions = rec.prescriptions.map(p => {
            if (p.id === prescriptionId) {
              logAuditEvent(
                'Prescription Dispensed',
                'Pharmacy & Therapeutics Module',
                `Dispensed medication ${p.drugName} (${p.dosage}) for record ${recordId}`
              );
              return {
                ...p,
                status: 'dispensed' as const,
                dispensedAt: nowStr,
                dispensedBy: currentUser?.name || 'Pharmacist on Duty',
              };
            }
            return p;
          });
          return { ...rec, prescriptions: updatedPrescriptions };
        }
        return rec;
      })
    );
  };

  const getAllPrescriptions = () => {
    const list: { prescription: PrescriptionItem; record: MedicalRecord; patient?: Patient }[] = [];
    medicalRecords.forEach(rec => {
      const patient = getPatientById(rec.patientId);
      rec.prescriptions.forEach(rx => {
        list.push({
          prescription: rx,
          record: rec,
          patient,
        });
      });
    });
    return list.sort((a, b) => {
      if (a.prescription.status === 'pending' && b.prescription.status !== 'pending') return -1;
      if (a.prescription.status !== 'pending' && b.prescription.status === 'pending') return 1;
      return 0;
    });
  };

  const requestLabTest = (test: Omit<LabTest, 'id' | 'requestDate' | 'status'>): LabTest => {
    const newId = `LAB-2026-${String(labTests.length + 1).padStart(3, '0')}`;
    const dateStr = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos',
      dateStyle: 'short',
      timeStyle: 'medium',
    }) + ' WAT';

    const newTest: LabTest = {
      ...test,
      id: newId,
      requestDate: dateStr,
      status: 'requested',
    };

    setLabTests(prev => [newTest, ...prev]);
    logAuditEvent(
      'Laboratory Investigation Ordered',
      'Diagnostic Laboratory Module',
      `Requested ${test.testName} (${test.priority}) for patient ${test.patientId}`
    );
    return newTest;
  };

  const updateLabTestResult = (id: string, results: string, scientistNotes?: string) => {
    const completedStr = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos',
      dateStyle: 'short',
      timeStyle: 'medium',
    }) + ' WAT';

    setLabTests(prev =>
      prev.map(t => {
        if (t.id === id) {
          const updated: LabTest = {
            ...t,
            results,
            scientistNotes,
            status: 'completed',
            completedDate: completedStr,
          };
          logAuditEvent(
            'Lab Results Verified & Uploaded',
            'Diagnostic Laboratory Module',
            `Validated findings for ${t.testName} (ID: ${id})`
          );
          return updated;
        }
        return t;
      })
    );
  };

  const triggerCloudBackup = () => {
    const nowStr = new Date().toLocaleString('en-US', {
      timeZone: 'Africa/Lagos',
      dateStyle: 'short',
      timeStyle: 'medium',
    }) + ' WAT';
    setLastCloudBackup(nowStr);
    setIsCloudSynced(true);
    logAuditEvent(
      'Cloud Backup & Synchronization',
      'Database & Cloud Storage Module',
      `Secure encrypted database snapshot synchronized to Chidicon Cloud Storage Cluster`
    );
  };

  const exportDatabaseJson = (): string => {
    const payload = {
      exportMetadata: {
        facility: 'Chidicon Medical Centre, Owerri, Imo State, Nigeria',
        system: 'Cloud-Based Health Information System (HIS)',
        version: '1.0-Cloud',
        exportedAt: new Date().toISOString(),
        exportedBy: currentUser?.name || 'Administrator',
      },
      patients,
      appointments,
      medicalRecords,
      labTests,
      auditLogs,
    };
    logAuditEvent(
      'Database Backup Export',
      'Security & Storage Module',
      'Exported full JSON snapshot of patient and clinical tables'
    );
    return JSON.stringify(payload, null, 2);
  };

  const importDatabaseJson = (jsonData: string): boolean => {
    try {
      const data = JSON.parse(jsonData);
      if (data.patients && Array.isArray(data.patients)) {
        setPatients(data.patients);
      }
      if (data.appointments && Array.isArray(data.appointments)) {
        setAppointments(data.appointments);
      }
      if (data.medicalRecords && Array.isArray(data.medicalRecords)) {
        setMedicalRecords(data.medicalRecords);
      }
      if (data.labTests && Array.isArray(data.labTests)) {
        setLabTests(data.labTests);
      }
      if (data.auditLogs && Array.isArray(data.auditLogs)) {
        setAuditLogs(data.auditLogs);
      }
      triggerCloudBackup();
      logAuditEvent(
        'Database Restored from Backup',
        'Security & Storage Module',
        'Successfully restored health information tables from imported JSON archive'
      );
      return true;
    } catch (e) {
      console.error('Failed to import database archive', e);
      return false;
    }
  };

  const resetToDefaultData = () => {
    setPatients(INITIAL_PATIENTS);
    setAppointments(INITIAL_APPOINTMENTS);
    setMedicalRecords(INITIAL_MEDICAL_RECORDS);
    setLabTests(INITIAL_LAB_TESTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    triggerCloudBackup();
    logAuditEvent(
      'System Database Reset',
      'Administrator Module',
      'Reset all hospital records to standard initial benchmark database'
    );
  };

  const getHospitalStats = (): HospitalStats => {
    const todayStr = '2026-09-01';
    const activeApts = appointments.filter(a => a.date === todayStr && a.status !== 'cancelled').length;
    const consultations = medicalRecords.filter(r => r.date.includes('2026-09-01') || r.date.includes('09/01/2026')).length || 4;
    
    let pendingRx = 0;
    medicalRecords.forEach(rec => {
      rec.prescriptions.forEach(p => {
        if (p.status === 'pending') pendingRx++;
      });
    });

    // Diagnoses frequency
    const diagCount: { [key: string]: number } = {
      'Acute Malaria (P. falciparum)': 24,
      'Essential Hypertension': 18,
      'Type 2 Diabetes Mellitus': 12,
      'Typhoid Enteritis': 9,
      'Upper Respiratory Infection': 8,
      'Peptic Ulcer Disease': 6,
      'Bronchial Asthma': 5,
    };
    
    medicalRecords.forEach(m => {
      const diag = m.diagnosis.split('(')[0].trim();
      diagCount[diag] = (diagCount[diag] || 0) + 1;
    });

    const totalDiagnoses = Object.values(diagCount).reduce((a, b) => a + b, 0);
    const topDiagnoses = Object.entries(diagCount)
      .map(([diagnosis, count]) => ({
        diagnosis,
        count,
        percentage: Math.round((count / totalDiagnoses) * 100),
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    const maleCount = patients.filter(p => p.gender === 'Male').length;
    const femaleCount = patients.filter(p => p.gender === 'Female').length;

    return {
      totalPatients: patients.length,
      activeAppointmentsToday: activeApts,
      consultationsToday: consultations,
      pendingPrescriptions: pendingRx,
      monthlyRegistrations: [
        { month: 'Jan', count: 28 },
        { month: 'Feb', count: 35 },
        { month: 'Mar', count: 42 },
        { month: 'Apr', count: 39 },
        { month: 'May', count: 48 },
        { month: 'Jun', count: 54 },
        { month: 'Jul', count: 62 },
        { month: 'Aug', count: 71 },
        { month: 'Sep', count: patients.length + 15 },
      ],
      topDiagnoses,
      genderDistribution: [
        { gender: 'Male', count: maleCount },
        { gender: 'Female', count: femaleCount },
      ],
      departmentLoad: [
        { department: 'General Outpatient (GOPD)', count: 45 },
        { department: 'Internal Medicine', count: 28 },
        { department: 'Paediatrics', count: 18 },
        { department: 'Obstetrics & Gynaecology', count: 22 },
        { department: 'Surgery & Orthopaedics', count: 12 },
      ],
    };
  };

  return (
    <HospitalContext.Provider
      value={{
        patients,
        appointments,
        medicalRecords,
        labTests,
        auditLogs,
        isCloudSynced,
        lastCloudBackup,
        registerPatient,
        updatePatient,
        addPatientVitals,
        getPatientById,
        createAppointment,
        updateAppointmentStatus,
        createMedicalRecord,
        updateMedicalRecord,
        dispensePrescription,
        getAllPrescriptions,
        requestLabTest,
        updateLabTestResult,
        logAuditEvent,
        triggerCloudBackup,
        exportDatabaseJson,
        importDatabaseJson,
        resetToDefaultData,
        getHospitalStats,
      }}
    >
      {children}
    </HospitalContext.Provider>
  );
};

export const useHospital = () => {
  const context = useContext(HospitalContext);
  if (!context) {
    throw new Error('useHospital must be used within a HospitalProvider');
  }
  return context;
};
